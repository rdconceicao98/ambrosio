<?php
/**
 * Class Webdados_Shop_Updater_KK file.
 * Updater for PT Woo Plugins, v9, 2024-03-29
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Our main class
 */
class Webdados_Shop_Updater_KK {

	/**
	 * API URL
	 *
	 * @var string $api_url The API domain.
	 */
	public $api_url = 'https://ptwooplugins.com/';

	/**
	 * Options prefix
	 *
	 * @var string $options_prefix The prefix to use in options.
	 */
	public $options_prefix = 'wc_feed_kuantokusta_pro';

	// phpcs:disable Squiz.Commenting.VariableComment.Missing, Squiz.Commenting.VariableComment.MissingVar

	/**
	 * Update properties
	 */
	public $slug              = '';
	public $plugin            = '';
	public $plugin_version    = '';
	public $product_unique_id = '';
	public $licence_key       = '';
	public $plugin_domain     = '';
	public $translation_slug  = '';
	public $plugin_name       = '';

	// phpcs:enable

	/**
	 * Constructor
	 *
	 * @param string $slug The plugin slug.
	 * @param string $plugin The plugin basename.
	 * @param string $plugin_version The plugin version.
	 * @param string $product_unique_id The plugin unique ID.
	 * @param string $licence_key The plugin license key.
	 * @param string $plugin_domain The plugin activation domain.
	 * @param string $translation_slug The plugin slug for translation updates.
	 * @param string $plugin_name The plugin name for expired notices.
	 */
	public function __construct( $slug, $plugin, $plugin_version, $product_unique_id, $licence_key, $plugin_domain, $translation_slug = '', $plugin_name = '' ) {
		$this->slug              = $slug;
		$this->plugin            = $plugin;
		$this->plugin_version    = $plugin_version;
		$this->product_unique_id = $product_unique_id;
		$this->licence_key       = $licence_key;
		$this->plugin_domain     = $plugin_domain;
		$this->translation_slug  = $translation_slug;
		$this->plugin_name       = $plugin_name;
		// Translations
		if ( ! empty( $this->translation_slug ) ) {
			require_once 'class-webdados-shop-translations-updater.php';
			\PTWooPlugins\WC_Feed_KuantoKusta_Pro\Traduttore_Registry\add_project(
				'plugin',
				$this->translation_slug,
				str_replace( 'https://', 'https://translations.', $this->api_url ) . 'glotpress/api/translations/' . $this->translation_slug . '/'
			);
		}
		// Expired notice
		if ( is_admin() && intval( get_option( $this->options_prefix . '_license_' . $this->product_unique_id . '_expired' ) ) === 1 ) {
			add_action( 'admin_notices', array( $this, 'expired_notice' ) );
		}
		// Translations notice
		if ( determine_locale() !== 'en_US' ) {
			add_action( 'admin_notices', array( $this, 'translations_notice' ) );
		}
	}

	/**
	 * Prepare request
	 *
	 * @param string $action The action to perform on the API.
	 * @param array  $args Arguments not used.
	 * @return array
	 */
	public function prepare_request( $action, $args = array() ) {
		global $wp_version;

		$request = array(
			'woo_sl_action'     => $action,
			'version'           => $this->plugin_version,
			'product_unique_id' => $this->product_unique_id,
			'licence_key'       => $this->licence_key,
			'domain'            => $this->plugin_domain,
			'wp-version'        => $wp_version,
			'api_version'       => '1.1',
		);
		return $request;
	}

	/**
	 * API Call
	 *
	 * @param object $result The original result from WordPress.
	 * @param string $action The action to perform on the API.
	 * @param array  $args Arguments for the API call.
	 * @return object
	 */
	public function plugins_api_call( $result, $action, $args ) {

		if ( isset( $args->slug ) && $args->slug !== $this->slug ) {
			// Not our plugin - Do not mess with it
			return $result;
		}

		if ( ! is_object( $args ) || ! isset( $args->slug ) || $args->slug !== $this->slug ) {
			return $result;
		}

		$request_string = $this->prepare_request( $action, $args );
		if ( $request_string === false ) {
			return new WP_Error( 'plugins_api_failed', 'An error occour when try to identify the plugin.' . '&lt;/p> &lt;p>&lt;a href=&quot;?&quot; onclick=&quot;document.location.reload(); return false;&quot;>' . 'Try again' . '&lt;/a>' ); // phpcs:ignore Generic.Strings.UnnecessaryStringConcat.Found
		}

		$request_uri = $this->api_url . '?' . http_build_query( $request_string, '', '&' );

		$data = wp_remote_get( $request_uri );
		if ( is_wp_error( $data ) || $data['response']['code'] !== 200 ) {
			return new WP_Error( 'plugins_api_failed', 'An Unexpected HTTP Error occurred during the API request.' . '&lt;/p> &lt;p>&lt;a href=&quot;?&quot; onclick=&quot;document.location.reload(); return false;&quot;>' . 'Try again' . '&lt;/a>', $data->get_error_message() ); // phpcs:ignore Generic.Strings.UnnecessaryStringConcat.Found
		}

		$response_block = json_decode( $data['body'] );

		// Retrieve the last message within the $response_block.
		$response_block = $response_block[ count( $response_block ) - 1 ];
		$response       = $response_block->message;
		if ( is_object( $response ) && ! empty( $response ) ) {

			// Include slug and plugin data.
			$response->slug     = $this->slug;
			$response->plugin   = $this->plugin;
			$response->sections = (array) $response->sections;
			$response->banners  = (array) $response->banners;

			return $response;
		}

		return $result;
	}

	/**
	 * Check for plugin update
	 *
	 * @param object $checked_data The original result from WordPress.
	 */
	public function check_for_plugin_update( $checked_data ) {

		if ( empty( $checked_data->checked ) ) {
			return $checked_data;
		}

		$request_string = $this->prepare_request( 'plugin_update' );
		if ( $request_string === false ) {
			return $checked_data;
		}

		// Start checking for an update.
		$request_uri = $this->api_url . '?' . http_build_query( $request_string, '', '&' );

		$data = wp_remote_get( $request_uri );
		if ( is_wp_error( $data ) || $data['response']['code'] !== 200 ) {
			return $checked_data;
		}

		$response_block = json_decode( $data['body'] );
		if ( ! is_array( $response_block ) || count( $response_block ) < 1 ) {
			return $checked_data;
		}

		// Retrieve the last message within the $response_block.
		$response_block = $response_block[ count( $response_block ) - 1 ];
		$response       = isset( $response_block->message ) ? $response_block->message : '';
		if ( is_object( $response ) && ! empty( $response ) ) {
			update_option( $this->options_prefix . '_license_' . $this->product_unique_id . '_expired', 0, false );
			// include slug and plugin data
			$response->slug                          = $this->slug;
			$response->plugin                        = $this->plugin;
			$response->icons                         = ! empty( $response->icons ) ? (array) $response->icons : array();
			$checked_data->response[ $this->plugin ] = $response;
			// maybe set as expired
			if ( empty( $response->package ) && stristr( $response->upgrade_notice, 'expired' ) ) {
				update_option( $this->options_prefix . '_license_' . $this->product_unique_id . '_expired', 1, false );
			}
			// maybe set as refunded
			if ( empty( $response->package ) && stristr( $response->upgrade_notice, 'refunded' ) ) {
				update_option( $this->options_prefix . '_license_' . $this->product_unique_id . '_refunded', 1, false );
			}
		} elseif ( is_string( $response ) ) {
			// Expired?
			if ( stristr( $response, 'expired' ) ) {
				update_option( $this->options_prefix . '_license_' . $this->product_unique_id . '_expired', 1, false );
			}
			// Refunded?
			if ( stristr( $response, 'refunded' ) ) {
				update_option( $this->options_prefix . '_license_' . $this->product_unique_id . '_refunded', 1, false );
			}
		}

		return $checked_data;
	}

	/**
	 * Activate plugin on this domain
	 */
	public function activate() {
		$args        = array(
			'woo_sl_action'     => 'activate',
			'licence_key'       => $this->licence_key,
			'product_unique_id' => $this->product_unique_id,
			'domain'            => $this->plugin_domain,
		);
		$request_uri = $this->api_url . '?' . http_build_query( $args, '', '&' );
		$data        = wp_remote_get( $request_uri );
		if ( is_wp_error( $data ) || $data['response']['code'] !== 200 ) {
			$returner = array(
				'success' => false,
				'message' => sprintf( 'There was a problem connecting to %s.', $request_uri ),
			);
			return $returner;
		}
		$response_block = json_decode( $data['body'] );
		$response_block = $response_block[ count( $response_block ) - 1 ];
		$response       = $response_block->message;
		if ( isset( $response_block->status ) ) {
			if (
				$response_block->status === 'success' &&
				(
					$response_block->status_code === 's100' ||
					$response_block->status_code === 's101'
				)
			) {
				$returner = array(
					'success' => true,
				);
				return $returner;
			} else {
				$returner = array(
					'success' => false,
					'message' => sprintf( 'There was a problem activating the licence: %s', $response_block->message ),
				);
				return $returner;
			}
		} else {
			$returner = array(
				'success' => false,
				'message' => sprintf( 'There was a problem with the data block received from %s', $request_uri ),
			);
			return $returner;
		}
	}

	/**
	 * Get support link
	 */
	public function get_support_link() {
		$url = add_query_arg( 'support', $this->licence_key, $this->api_url );
		return $url;
	}

	/**
	 * Get renew link
	 */
	public function get_renew_link() {
		$url = add_query_arg( 'renew', $this->licence_key, $this->api_url );
		return $url;
	}

	/**
	 * Get update information about the plugin
	 *
	 * @param string $plugin  The plugin unique ID.
	 */
	public function version_update_information( $plugin ) {
		if ( $plugin === $this->product_unique_id ) {
			if ( $update_information = $this->get_version_update_information( $plugin ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.Found, Squiz.PHP.DisallowMultipleAssignments.FoundInControlStructure
				if ( version_compare( $update_information['version'], $this->plugin_version, '>' ) ) {
					echo '<a href="update-core.php?force-check=1">' . esc_html__( 'Update available', 'feed-kuantokusta-for-woocommerce-pro' ) . ': ' . esc_html( $update_information['version'] ) . '</a>' . esc_html( $update_information['extra_notice'] );
				} else {
					echo esc_html__( 'Plugin up to date', 'feed-kuantokusta-for-woocommerce-pro' ) . esc_html( $update_information['extra_notice'] );
				}
			} else {
				echo esc_html__( 'Unable to get update information', 'feed-kuantokusta-for-woocommerce-pro' );
			}
		} elseif ( has_action( 'wp_ajax_' . $plugin . '_check_update_version' ) ) {
			do_action( 'wp_ajax_' . $plugin . '_check_update_version' );
		} else {
			echo esc_html__( 'Unable to get update information', 'feed-kuantokusta-for-woocommerce-pro' );
		}
	}

	/**
	 * Get new plugin version
	 *
	 * @param string $plugin  The plugin unique ID.
	 */
	public function get_version_update_information( $plugin ) {
		// Verify from transient first
		if ( false === ( $updated_version = get_transient( $this->options_prefix . '_updated_version_' . $plugin ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.Found, Squiz.PHP.DisallowMultipleAssignments.FoundInControlStructure
			if ( $response = $this->get_plugin_update_information( 'plugin_information' ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.Found, Squiz.PHP.DisallowMultipleAssignments.FoundInControlStructure
				// Set transient
				set_transient( $this->options_prefix . '_updated_version_' . $plugin, $response->version, 2 * HOUR_IN_SECONDS );
				// Return
				return array(
					'version'      => $response->version,
					'extra_notice' => ( empty( $response->package ) && stristr( $response->upgrade_notice, 'expired' ) ) ? ' - ' . __( 'License expired', 'feed-kuantokusta-for-woocommerce-pro' ) : '',
				);
			}
		} else {
			return array(
				'version'      => $updated_version,
				'extra_notice' => '',
			);
		}
		return false;
	}

	/**
	 * Get new plugin update information
	 *
	 * @param string $method The method for the API call.
	 */
	public function get_plugin_update_information( $method ) {
		// Set as not expired
		update_option( $this->options_prefix . '_license_' . $this->product_unique_id . '_expired', 0, false );

		// Start checking for an update.
		$request_string = $this->prepare_request( $method );
		$request_uri    = $this->api_url . '?' . http_build_query( $request_string, '', '&' );

		$data = wp_remote_get( $request_uri );
		if ( is_wp_error( $data ) || $data['response']['code'] !== 200 ) {
			return false;
		}

		$response_block = json_decode( $data['body'] );
		if ( ! is_array( $response_block ) || count( $response_block ) < 1 ) {
			return false;
		}

		// Retrieve the last message within the $response_block.
		$response_block = $response_block[ count( $response_block ) - 1 ];
		$response       = isset( $response_block->message ) ? $response_block->message : '';
		if ( is_object( $response ) && ! empty( $response ) ) {
			// Expired?
			if ( empty( $response->package ) && stristr( $response->upgrade_notice, 'expired' ) ) {
				update_option( $this->options_prefix . '_license_' . $this->product_unique_id . '_expired', 1, false );
			}
			// Refunded?
			if ( empty( $response->package ) && stristr( $response->upgrade_notice, 'refunded' ) ) {
				update_option( $this->options_prefix . '_license_' . $this->product_unique_id . '_refunded', 1, false );
			}
			return $response;
		} elseif ( is_string( $response ) ) {
			// Expired?
			if ( stristr( $response, 'expired' ) ) {
				update_option( $this->options_prefix . '_license_' . $this->product_unique_id . '_expired', 1, false );
			}
			// Refunded?
			if ( stristr( $response, 'refunded' ) ) {
				update_option( $this->options_prefix . '_license_' . $this->product_unique_id . '_refunded', 1, false );
			}
		}
		return false;
	}

	/**
	 * Notice locations
	 */
	private function is_notice_location() {
		global $pagenow;
		if (
			$pagenow
			&&
			apply_filters(
				$this->options_prefix . '_show_expired_notices', // Allow to change
				(
					// Each plugin should return true on their settings page
					apply_filters( $this->options_prefix . '_is_plugin_settings_page', false, $pagenow )
					||
					// Plugins page
					( $pagenow === 'plugins.php' )
					||
					// We might need to change the follwing rules if we start shipping non-WooCommerce plugins
					// WooCommerce orders - HPOS (list and edit page)
					( $pagenow === 'admin.php' && isset( $_GET['page'] ) && $_GET['page'] === 'wc-orders' ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					||
					// WooCommerce orders - Posts (list)
					( $pagenow === 'edit.php' && isset( $_GET['post_type'] ) && $_GET['post_type'] === 'shop_order' ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
					||
					// WooCommerce orders - Posts (edit page)
					( $pagenow === 'post.php' && isset( $_GET['post'] ) && intval( $_GET['post'] ) > 0 && get_post_type( intval( $_GET['post'] ) ) === 'shop_order' ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				)
			)
		) {
			return true;
		}
		return false;
	}

	/**
	 * Display expired notice
	 */
	public function expired_notice() {
		if ( $this->is_notice_location() ) {
			$message = sprintf(
				/* translators: %1$s: plugin name, %2$s: license details link, %3$s: email contact link */
				__( '<strong>The "%1$s" plugin license is expired.</strong><br/>To keep receiving automatic security and feature updates, as well as technical support, you need to <a href="%2$s" target="_blank">renew your license</a> or <a href="%3$s" target="_blank">contact us</a>.', 'feed-kuantokusta-for-woocommerce-pro' ),
				$this->plugin_name,
				$this->get_support_link(),
				esc_url(
					'mailto:info@ptwooplugins.com?subject=' . sprintf(
						/* translators: %1$s: plugin name, %2$s: website domain */
						__( '%1$s license expired on %2$s', 'feed-kuantokusta-for-woocommerce-pro' ),
						$this->plugin_name,
						$this->plugin_domain
					)
				)
			);
			echo wp_kses_post( sprintf( '<div class="notice notice-error"><p>%s</p></div>', $message ) );
		}
	}

	/**
	 * Display translations notice
	 */
	public function translations_notice() {
		if ( $this->is_notice_location() ) {
			$transient = get_site_transient( 'update_plugins' );
			if ( ! empty( $transient->translations ) ) {
				foreach ( $transient->translations as $translation ) {
					if ( $translation['type'] === 'plugin' && $translation['slug'] === $this->translation_slug && $translation['language'] === determine_locale() ) {
						$message = sprintf(
							/* translators: %1$s: plugin name, %2$s: link opening tag, %3$s: link closing tag link */
							__( '<strong>There are translation updates for the "%1$s" plugin.</strong><br/>Please go to %2$sDashboard &gt; Updates%3$s and click on "Update Translations".', 'feed-kuantokusta-for-woocommerce-pro' ),
							$this->plugin_name,
							'<a href="update-core.php">',
							'</a>'
						);
						echo wp_kses_post( sprintf( '<div class="notice notice-error"><p>%s</p></div>', $message ) );
					}
				}
			}
		}
	}
}