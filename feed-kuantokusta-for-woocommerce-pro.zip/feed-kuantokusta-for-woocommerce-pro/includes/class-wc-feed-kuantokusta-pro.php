<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Our main class
 *
 */
final class WC_Feed_KuantoKusta_Pro {
	
	/* ID, Version, Plugin mode, Integrations... */
	public $version       = false;
	public $fields        = array();
	public $field_origins = false;
	public $bigbuy_active = false;
	public $wpml_active   = false;

	/* Update stuff */
	public $plugin_name;
	public $license_key;
	public $plugin_update_id = 'KKPRO';
	public $plugin_domain;
	public $updater;
	public $plugin_file      = KUANTOKUSTA_PRO_PLUGIN_FILE;
	public $plugin_slug      = KUANTOKUSTA_PRO_PLUGIN_SLUG;
	public $plugin_path      = KUANTOKUSTA_PRO_PLUGIN_PATH;
	public $plugin_basename  = KUANTOKUSTA_PRO_PLUGIN_BASENAME;

	/* Single instance */
	protected static $_instance = null;

	/* Constructor */
	public function __construct() {
		if ( class_exists( 'WC_Feed_KuantoKusta' ) ) { // Just in case - https://wordpress.org/support/topic/versao-3-1-com-erro-fatal/
			if ( ! function_exists( 'get_plugin_data' ) ) require_once( ABSPATH . 'wp-admin/includes/plugin.php' ); //Should not be necessary, but we never know...
			$data = get_plugin_data( KUANTOKUSTA_PRO_PLUGIN_FILE, false, false  );
			$this->version     = $data['Version'];
			$this->plugin_name = $data['Name'];
			//Update stuff
			$this->license_key      = get_option( 'wc_feed_kuantokusta_pro_key' );
			$wpurl                  = site_url();
			$this->plugin_domain    = str_replace(
										(
											( ! empty( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] !== 'off' )
											||
											( ! empty( $_SERVER['SERVER_PORT'] ) && $_SERVER['SERVER_PORT'] == 443 )
										)
										? 'https://' : 'http://',
										'',
										$wpurl
									);
			//Other variables
			$this->wpml_active   = function_exists( 'icl_object_id' ) && function_exists( 'icl_register_string' ) && class_exists( 'SitePress' ) && class_exists( 'woocommerce_wpml' );
			$this->bigbuy_active = class_exists( 'WcMipconnector' );
			//Hooks
			$this->init_hooks();
		} else {
			add_action( 'admin_notices', 'admin_notices_kuantokusta_woocommerce_pro_not_active' );
		}
	}

	/* Ensures only one instance of our plugin is loaded or can be loaded */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/* Hooks */
	private function init_hooks() {
		add_filter( 'init', array( $this, 'init_fields' ), 999 ); //As late as possible because of taxonomies registration - This could be avoided if we used Ajax to load the field
		add_action( 'init', array( $this, 'update_checker' ) );
		add_action( 'woocommerce_update_options_kuantokusta', array( $this, 'activate_license' ), 1 );
		add_filter( 'kuantokusta_settings_tab_title', array( $this, 'settings_tab_title' ) );
		add_filter( 'kuantokusta_settings_title', array( $this, 'settings_title' ) );
		add_filter( 'kuantokusta_product_data_panel_end', array( $this, 'product_fields' ) );
		add_action( 'kuantokusta_process_product_meta', array( $this, 'process_product_fields' ) );
		add_action( 'kuantokusta_documentation_before_fields_inner', array( $this, 'documentation_before_fields' ), 20 );
		add_filter( 'kuantokusta_documentation_fields', array( $this, 'kuantokusta_documentation_fields' ) );
		add_filter( 'kuantokusta_documentation_hooks', array( $this, 'kuantokusta_documentation_hooks' ) );
		add_action( 'kuantokusta_settings_footer', array( $this, 'settings_page_footer' ) );
		add_action( 'wp_ajax_kk_field_origins', array( $this, 'wp_ajax_field_origins' ) );
		add_filter( 'wc_settings_kuantokusta_settings', array( $this, 'wc_settings_kuantokusta_settings' ) );
		add_filter( 'kuantokusta_hide_settings_pro_ad', '__return_true' );
		//Custom variation fields
		add_action( 'woocommerce_product_after_variable_attributes', array( $this, 'woocommerce_product_after_variable_attributes' ), 10, 3 );
		add_action( 'woocommerce_save_product_variation', array( $this, 'woocommerce_save_product_variation' ), 10, 2 );
		//Manipulate feed - Priority = 1 so we are the first and other plugins can jump in after
		add_filter( 'kuantokusta_product_node_default_xml_fields', array( $this, 'product_node_default_xml_fields' ), 1, 3 );
		add_filter( 'kuantokusta_product_node_variation_xml_fields', array( $this, 'product_node_variation_xml_fields' ), 1, 3 );
		add_filter( 'kuantokusta_product_node_default_preparation_days_max', array( $this, 'get_product_preparation_days_max_backorder' ), 1, 3 );
		add_filter( 'kuantokusta_product_node_variation_preparation_days_max', array( $this, 'get_product_variation_preparation_days_max_backorder' ), 1, 3 );
		add_filter( 'kuantokusta_product_node_default_ean', array( $this, 'get_product_ean' ), 1, 2 );
		add_filter( 'kuantokusta_product_node_variation_ean', array( $this, 'get_product_variation_variation_ean' ), 1, 3 );
		add_filter( 'kuantokusta_product_node_default_brand', array( $this, 'get_product_brand' ), 1, 2 );
		add_filter( 'kuantokusta_product_node_variation_brand', array( $this, 'get_product_variation_brand' ), 1, 3 );
		add_filter( 'kuantokusta_product_node_default_categories', array( $this, 'get_product_category' ), 1, 2 );
		add_filter( 'kuantokusta_product_node_variation_categories', array( $this, 'get_product_variation_category' ), 1, 3 );
		add_filter( 'kuantokusta_product_node_pre_variation_title', array( $this, 'get_product_variation_title' ), 1, 3 );
		add_filter( 'kuantokusta_product_node_variation_title_append_description', array( $this, 'variation_title_append_description' ), 1, 3 );
		//Discount Rules for WooCommerce compatibility - https://wordpress.org/plugins/woo-discount-rules/
		if ( defined( 'WDR_VERSION' ) && version_compare( WDR_VERSION, '2.3.8', '>=' ) ) {
			add_filter( 'kuantokusta_product_node_default_current_price', array( &$this, 'woo_discount_rules_default_current_price' ), 10, 3 );
			add_filter( 'kuantokusta_product_node_variation_current_price', array( &$this, 'woo_discount_rules_variation_current_price' ), 10, 3 );
		}
	}

	/* Update Checker */
	public function update_checker() {
		if ( intval( get_option( WC_Feed_KuantoKusta()->id . '_pro' . '_license_' . $this->plugin_update_id . '_refunded' ) ) === 1 ) {
			// License was refunded - remove it
			delete_option( WC_Feed_KuantoKusta()->id . '_pro_key' );
			delete_option( WC_Feed_KuantoKusta()->id . '_activation_key' );
		}
		require_once( 'class-webdados-shop-updater.php' );
		$this->updater = new Webdados_Shop_Updater_KK(
			$this->plugin_slug,
			$this->plugin_basename,
			$this->version,
			$this->plugin_update_id,
			$this->license_key,
			$this->plugin_domain,
			'feed-kuantokusta-for-woocommerce-pro',
			$this->plugin_name
		);
		if ( $this->license_validated() ) {
			// Take over the update check.
			add_filter( 'pre_set_site_transient_update_plugins', array( $this->updater, 'check_for_plugin_update' ) );
			// Take over the Plugin info screen.
			add_filter( 'plugins_api', array( $this->updater, 'plugins_api_call' ), 10, 3 );
			// Check plugin updates on settings screen
			add_action( 'wp_ajax_' . WC_Feed_KuantoKusta()->id . '_pro_check_update_version', array( $this, 'version_update_information' ) );
		}
		// Notice if expired on the settings screen
		add_filter(
			WC_Feed_KuantoKusta()->id . '_pro' . '_is_plugin_settings_page',
			function ( $is_plugin_settings_page, $pagenow ) {
				return 'admin.php' == $pagenow && isset( $_GET['page'] ) && 'wc-settings' == $_GET['page'] && isset( $_GET['tab'] ) && 'kuantokusta' == $_GET['tab']; //phpcs:ignore WordPress.Security.NonceVerification.Recommended
			},
			10,
			2
		);
	}

	/* Update version checker */
	public function version_update_information() {
		if ( isset( $_POST['plugin'] ) && $plugin = sanitize_text_field( $_POST['plugin'] ) ) {
			$this->updater->version_update_information( $plugin );
		} else {
			echo __( 'Unable to get update information', 'feed-kuantokusta-for-woocommerce-pro' ); 
		}
		wp_die();
	}

	/* Get main plugin setting */
	public function get_setting( $setting ) {
		return WC_Feed_KuantoKusta()->get_setting( $setting );
	}

	/* Validate activation */
	public function license_validated() {

		if ( ( ! empty( $this->license_key ) ) && ( ! empty( $this->plugin_domain ) ) ) {

			// Regular checking without WPML
			if ( \get_option( WC_Feed_KuantoKusta()->id . '_activation_key' ) === md5( $this->license_key . $this->plugin_domain ) ) {
				return true;
			} elseif ( $this->wpml_active ) {

				// WPML active: we need to check for all domains, if it's set for a different domain per language
				global $sitepress;
				if ( 2 === (int) $sitepress->get_setting( 'language_negotiation_type' ) ) {
					$languages = apply_filters( 'wpml_active_languages', null );
					if ( is_array( $languages ) && count( $languages ) > 0 ) {
						foreach ( $languages as $language ) {
							$domain = wp_parse_url( $language['url'] );
							$domain = $domain['host'];
							if ( \get_option( WC_Feed_KuantoKusta()->id . '_activation_key' ) === md5( $this->license_key . $domain ) ) {
								return true;
							}
						}
					}
				}
			}
		}

		return false;
	}
	public function activate_license() {
		if ( isset( $_POST[ WC_Feed_KuantoKusta()->id.'_pro_key' ] ) && $this->license_key != $_POST[ WC_Feed_KuantoKusta()->id.'_pro_key' ] ) {
			$this->license_key = $_POST[ WC_Feed_KuantoKusta()->id.'_pro_key' ];
			$this->updater->licence_key = $_POST[ WC_Feed_KuantoKusta()->id.'_pro_key' ];
			$activation = $this->updater->activate();
			if ( $activation['success'] ) {
				update_option( WC_Feed_KuantoKusta()->id.'_activation_key', md5( $this->license_key.$this->plugin_domain ) );
				delete_option( WC_Feed_KuantoKusta()->id . '_pro' . '_license_' . $this->plugin_update_id . '_refunded' );
			} else {
				//Do nothing
			}
		}
	}

	/* Fields */
	public function init_fields() {
		//License key
		$this->fields = array(
			'pro_key' => array(
				'comparison'       => true,
				'marketplace'      => true,
				'product'          => false,
				'settings'         => array(
					'id'               => 'pro_key',
					'after_id'         => 'plugin_mode',
					'name'             => __( 'PRO license key', 'feed-kuantokusta-for-woocommerce-pro' ),
					'type'             => 'text',
					'desc'             => sprintf(
						'%1$s<br/><span id="kk_api_version_update" data-plugin="%2$s">%3$s</span><br/>%4$s<br/>%5$s %6$s',
						//Validation and update checking
						__( 'Your PRO add-on license key', 'feed-kuantokusta-for-woocommerce-pro' ).' - '.(
							intval( get_option( WC_Feed_KuantoKusta()->id . '_pro' . '_license_' . $this->plugin_update_id . '_expired' ) ) === 1
							?
							sprintf(
								'<span style="color: red;">%s</span>',
								__( 'Expired', 'feed-kuantokusta-for-woocommerce-pro' )
							)
							:
							(
								$this->license_validated()
								?
								sprintf(
									'<span style="color: green;">%s</span>',
									__( 'Active', 'feed-kuantokusta-for-woocommerce-pro' )
								)
								:
								sprintf(
									'<span style="color: red;">%s</span>',
									__( 'Not active', 'feed-kuantokusta-for-woocommerce-pro' )
								)
							)
						),
						//Plugin update ID
						$this->plugin_update_id,
						//Update checking
						__( 'Checking for updates', 'feed-kuantokusta-for-woocommerce-pro' ),
						//FAQ
						//sprintf(
						//	'%1$s%2$s%3$s',
						//	sprintf(
						//		'- <a href="%s" target="_blank">',
						//		'https://ptwooplugins.com/faqs/'
						//	),
						//	__( 'FAQ', 'feed-kuantokusta-for-woocommerce-pro' ),
						//	'</a>'
						//),
						//Documentation
						sprintf(
							'%1$s%2$s%3$s',
							'- <a href="#kk_settings_section_docs" class="kk_settings_section_docs_toggle">',
							__( 'Documentation', 'feed-kuantokusta-for-woocommerce-pro' ),
							'</a>'
						),
						//Technical support link
						sprintf(
							'%1$s%2$s%3$s',
							sprintf(
								'- <a href="%s" target="_blank">',
								! empty( $this->updater ) ? $this->updater->get_support_link() : '#'
							),
							__( 'Technical support', 'feed-kuantokusta-for-woocommerce-pro' ),
							'</a>'
						),
						//Terms and conditions
						'<small>(<a href="https://ptwooplugins.com/privacy-policy/" target="_blank">'.__( 'Terms and conditions apply', 'feed-kuantokusta-for-woocommerce-pro' ).'</a>)</small>'
					),
					/*__( 'Your PRO add-on license key', 'feed-kuantokusta-for-woocommerce-pro' ).' - '.(
											intval( get_option( WC_Feed_KuantoKusta()->id . '_pro' . '_license_' . $this->plugin_update_id . '_expired' ) ) === 1
											?
											sprintf(
												'<span style="color: red;">%s</span>',
												__( 'Expired', 'feed-kuantokusta-for-woocommerce-pro' )
											)
											:
											(
												$this->license_validated()
												?
												sprintf(
													'<span style="color: green;">%1$s</style><br/>- <a href="#kk_settings_section_docs" class="kk_settings_section_docs_toggle">%2$s</a><br/>- <a href="%3$s" target="_blank">%4$s</a> <small>(<a href="%5$s" target="_blank">%6$s</a>)</small>',
													__( 'Active', 'feed-kuantokusta-for-woocommerce-pro' ),
													//Documentation
													__( 'Documentation', 'feed-kuantokusta-for-woocommerce-pro' ),
													//FAQ
													//'MISSING LINK',
													//__( 'FAQ', 'feed-kuantokusta-for-woocommerce-pro' ),
													//Technical support
													! empty( $this->updater ) ? $this->updater->get_support_link() : '#',
													__( 'Technical support', 'feed-kuantokusta-for-woocommerce-pro' ),
													//Terms and conditions
													'https://ptwooplugins.com/privacy-policy/',
													__( 'Terms and conditions apply', 'feed-kuantokusta-for-woocommerce-pro' ),
												)
												:
												sprintf( '<span style="color: red;">%s</style>', __( 'Not active', 'feed-kuantokusta-for-woocommerce-pro' ) )
											)
										),*/
					'desc_tip'         => false,
					'id_'              => 'pro_key',
				),
				'documentation'    => false,
				'hooks'            => false,

			),
		);

		if ( $this->license_validated() ) {
			$this->fields['pro_key']['settings']['custom_attributes']['readonly'] = 'readonly';
			$this->fields = array_merge( $this->fields, array(
				
				//Variations
				'variable_append_description' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'       => 'variable_append_description',
						'after_id' => 'variable_show_method',
						'name'     => __( 'Append description to title', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'     => 'select',
						'desc'     => __( 'If the variable description (or SKU or ID) should be appended to the title to better differentiate the product', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip' => true,
						'id_'      => 'variable_append_description',
						'options'  => array(
							'yes' => __( 'Yes', 'feed-kuantokusta-for-woocommerce-pro' ),
							'no'  => __( 'No', 'feed-kuantokusta-for-woocommerce-pro' ),
						),
						'class'    => '',
					),
					'documentation' => false,
					'hooks'         => false,
				),

				//Brand value origin
				'brandorigin_section_title' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'         => 'brandorigin_section_title',
						'after_id'   => 'stock_section_end',
						'name'       => __( 'Brand', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'       => 'title',
						'desc'       => false,
					),
					'documentation' => false,
					'hooks'         => false,
				),
				/*'brand_origin' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'       => 'brand_origin',
						'after_id' => 'stock_section_end',
						'name'     => __( 'Get brand from', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'     => 'select',
						'desc'     => __( 'Where to get the brand from', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip' => true,
						'id_'      => 'brand_origin',
						//'options'  => $this->get_field_origins(),
						'class'    => 'kk_field_origins'
					),
					'documentation' => false,
					'hooks'         => false,
				),*/
				'brand_origin' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'       => 'brand_origin',
						'after_id' => 'stock_section_end',
						'name'     => __( 'Get brand from', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'     => 'text', //We're using a text field and not a select because WooCommerce does not allow to see values that are not set as field options
						'desc'     => __( 'Where to get the brand from', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip' => true,
						'id_'      => 'brand_origin',
						'class'    => 'kk_field_origins',
						'custom_attributes' => array(
							'data-defaultlabel' => __( 'Field on the product KuantoKusta metabox', 'feed-kuantokusta-for-woocommerce-pro' ),
						),
					),
					'documentation' => false,
					'hooks'         => false,
				),
				'brand_origin_default_to_field' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'       => 'brand_origin_default_to_field',
						'after_id' => 'stock_section_end',
						'name'     => __( 'Default to our field', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'     => 'select',
						'desc'     => __( 'If not set on the custom field or taxonomy above, default to the field on the product KuantoKusta metabox', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip' => true,
						'id_'      => 'brand_origin_default_to_field',
						'options'  => array(
							'no'  => __( 'No', 'feed-kuantokusta-for-woocommerce-pro' ),
							'yes' => __( 'Yes', 'feed-kuantokusta-for-woocommerce-pro' ),
						),
						'class'    => '',
					),
					'documentation' => false,
					'hooks'         => false,
				),
				'brand_default_value' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'       => 'brand_default_value',
						'after_id' => 'stock_section_end',
						'name'     => __( 'Default brand', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'     => 'text',
						'desc'     => __( 'The default brand, if not set on the custom field or taxonomy above, or our field', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip' => true,
						'id_'      => 'brand_default_value',
						'class'    => '',
					),
					'documentation' => false,
					'hooks'         => false,
				),
				'brand_ref_origin' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'       => 'brand_ref_origin',
						'after_id' => 'stock_section_end',
						'name'     => __( 'Get brand SKU / MPN from', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'     => 'text', //We're using a text field and not a select because WooCommerce does not allow to sae values that are not set as field options
						'desc'     => __( 'Where to get the brand SKU / MPN from', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip' => true,
						'id_'      => 'brand_ref_origin',
						'class'    => 'kk_field_origins',
						'custom_attributes' => array(
							'data-defaultlabel' => __( 'Field on the product KuantoKusta metabox', 'feed-kuantokusta-for-woocommerce-pro' ),
						),
					),
					'documentation' => false,
					'hooks'         => false,
				),
				'brand_ref_origin_default_to_field' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'       => 'brand_ref_origin_default_to_field',
						'after_id' => 'stock_section_end',
						'name'     => __( 'Default to our field', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'     => 'select',
						'desc'     => __( 'If not set on the custom field or taxonomy above, default to the field on the product KuantoKusta metabox', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip' => true,
						'id_'      => 'brand_ref_origin_default_to_field',
						'options'  => array(
							'no'  => __( 'No', 'feed-kuantokusta-for-woocommerce-pro' ),
							'yes' => __( 'Yes', 'feed-kuantokusta-for-woocommerce-pro' ),
						),
						'class'    => '',
					),
					'documentation' => false,
					'hooks'         => false,
				),
				'brandorigin_section_end' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'         => 'brandorigin_section_end',
						'after_id'   => 'stock_section_end',
						'type'       => 'sectionend',
					),
					'documentation' => false,
					'hooks'         => false,
				),

				//EAN/UPC value origin
				'eanorigin_section_title' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'         => 'eanorigin_section_title',
						'after_id'   => 'stock_section_end',
						'name'       => __( 'EAN / UPC', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'       => 'title',
						'desc'       => false,
					),
					'documentation' => false,
					'hooks'         => false,
				),
				'ean_origin' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'       => 'ean_origin',
						'after_id' => 'stock_section_end',
						'name'     => __( 'Get EAN / UPC from', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'     => 'text', //We're using a text field and not a select because WooCommerce does not allow to sae values that are not set as field options
						'desc'     => __( 'Where to get the EAN / UPC from', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip' => true,
						'id_'      => 'ean_origin',
						'class'    => 'kk_field_origins',
						'custom_attributes' => array(
							'data-defaultlabel' => (
								get_option( WC_Feed_KuantoKusta()->id . '_ean_wc_migration' ) === 'done'
								?
								__( '"GTIN, UPC, EAN or ISBN" WooCommerce field', 'feed-kuantokusta-for-woocommerce-pro' )
								:
								__( '"GTIN, UPC, EAN or ISBN" WooCommerce field (or field on the KuantoKusta metabox - deprecated)', 'feed-kuantokusta-for-woocommerce-pro' )
							),
						),
					),
					'documentation' => false,
					'hooks'         => false,
				)
			) );
			if ( version_compare( WC_VERSION, '9.2', '>=' ) ) {
				if ( get_option( WC_Feed_KuantoKusta()->id . '_ean_wc_migration' ) !== 'yes' && get_option( WC_Feed_KuantoKusta()->id . '_ean_wc_migration' ) !== 'done' ) {
					if ( get_option( WC_Feed_KuantoKusta()->id . '_ean_wc_migration' ) === '' && get_option( WC_Feed_KuantoKusta()->id . '_ean_origin' ) === '' ) {
						// New install - Set it as done
						update_option( WC_Feed_KuantoKusta()->id . '_ean_wc_migration', 'done' );
					} else {
						$this->fields = array_merge( $this->fields, array(
							'ean_wc_migration' => array(
								'comparison'    => true,
								'marketplace'   => true,
								'product'       => false,
								'settings'      => array(
									'id'       => 'ean_wc_migration',
									'after_id' => 'stock_section_end',
									'name'     => __( 'Migrate our field to WooCommerce', 'feed-kuantokusta-for-woocommerce-pro' ),
									'type'     => 'checkbox', //We're using a text field and not a select because WooCommerce does not allow to sae values that are not set as field options
									'desc'     => __( 'Migrate our EAN field to the new WooCommerce 9.2 and above "GTIN, UPC, EAN or ISBN" field', 'feed-kuantokusta-for-woocommerce-pro' ) . ' &nbsp; ' . sprintf(
										'<span style="color: red;">%s</span>',
										__( 'Recommended - Our field values will replace the new WooCommerce field values if set', 'feed-kuantokusta-for-woocommerce-pro' )
									),
									'desc_tip' => false,
									'id_'      => 'ean_wc_migration',
								),
								'documentation' => false,
								'hooks'         => false,
							),
						) );
					}
				} elseif ( get_option( WC_Feed_KuantoKusta()->id . '_ean_wc_migration' ) === 'yes' ) {
					// Run migration
					global $wpdb;
					// Delete empty records
					$sql = "DELETE FROM {$wpdb->prefix}postmeta WHERE meta_key = '_kuantokusta_ean' AND TRIM( meta_value ) = ''";
					$wpdb->query( $sql );
					// Select post_ids that have our field set
					$sql = "SELECT post_id FROM {$wpdb->prefix}postmeta WHERE meta_key = '_kuantokusta_ean' AND meta_value NOT LIKE ''";
					$ids = $wpdb->get_results( $sql, ARRAY_A );
					if ( count( $ids ) > 0 ) {
						$temp_ids = array();
						foreach ( $ids as $id ) {
							$temp_ids[] = $id['post_id'];
						}
						$temp_ids = array_unique( $temp_ids );
						// Delete Woo meta
						$sql = "DELETE FROM {$wpdb->prefix}postmeta WHERE post_id IN (" . implode( ', ', $temp_ids ) . ") AND meta_key = '_global_unique_id'";
						$wpdb->query( $sql );
						// Move our meta to Woo meta
						$sql = "UPDATE {$wpdb->prefix}postmeta SET meta_key = '_global_unique_id' WHERE meta_key = '_kuantokusta_ean'";
						$wpdb->query( $sql );
					}
					// Set to done
					update_option( WC_Feed_KuantoKusta()->id . '_ean_wc_migration', 'done' );
				}
			}
			$this->fields = array_merge( $this->fields, array(
				'ean_origin_default_to_field' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'       => 'ean_origin_default_to_field',
						'after_id' => 'stock_section_end',
						'name'     => __( 'Default to our field', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'     => 'select',
						'desc'     => __( 'If not set on the custom field or taxonomy above, default to the field on the product KuantoKusta metabox', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip' => true,
						'id_'      => 'ean_origin_default_to_field',
						'options'  => array(
							'no'  => __( 'No', 'feed-kuantokusta-for-woocommerce-pro' ),
							'yes' => __( 'Yes', 'feed-kuantokusta-for-woocommerce-pro' ),
						),
						'class'    => '',
					),
					'documentation' => false,
					'hooks'         => false,
				),
				'eanorigin_section_end' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'         => 'eanorigin_section_end',
						'after_id'   => 'stock_section_end',
						'type'       => 'sectionend',
					),
					'documentation' => false,
					'hooks'         => false,
				),
				
				//Brand reference
				'brand_ref' => array(
					'comparison'       => false,
					'marketplace'      => true,
					'product'           => array(
						'id'               => '_kuantokusta_brand_sku',
						'label'            => __( 'Brand SKU / MPN', 'feed-kuantokusta-for-woocommerce-pro' ),
						'placeholder'      => '',
						'function'         => 'woocommerce_wp_text_input',
						'extra_attributes' => array(),
					),
					'settings'  => false,
					'documentation'     => array(
						'id'               => 'brand_ref',
						'desc'             => __( 'The product brand SKU / MPN from the KuantoKusta metabox on the product edit screen.', 'feed-kuantokusta-for-woocommerce-pro' ),
						'filter'           => true,
					),
					'hooks'             => array(
						'filters' => array(
							'kuantokusta_product_node_default_brand_ref' => array(
								'arguments' => array(
									'$brand_ref',
									'$product',
									'$product_type',
								),
								'desc' => __( 'Filter on the product brand SKU / MPN.', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
							'kuantokusta_product_node_variation_brand_ref' => array(
								'arguments' => array(
									'$brand_ref',
									'$product',
									'$variation',
								),
								'desc' => __( 'Filter on the product variation brand SKU / MPN.', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
						),
					),
				),
				//Shipping cost (express delivery)
				'shipping_cost_express' => array(
					'comparison'       => false,
					'marketplace'      => true,
					'product' => array(
						'id'               => '_kuantokusta_shipping_express',
						'label'            => __( 'Shipping cost (express delivery)', 'feed-kuantokusta-for-woocommerce-pro' ) . ' (' . get_woocommerce_currency_symbol() . ')',
						//'placeholder'      => sprintf( __( 'With tax - Blank for default (%s)', 'feed-kuantokusta-for-woocommerce-pro' ), $this->get_setting( 'shipping_cost_express_default' ) ),
						'placeholder'      => __( 'With tax - Blank for default (%s)', 'feed-kuantokusta-for-woocommerce-pro' ),
						'placeholder_default' => 'shipping_cost_express_default',
						'function'         => 'woocommerce_wp_text_input',
						'extra_attributes' => array(
							'data_type' => 'price',
						),
					),
					'settings'          => array(
						'id'               => 'shipping_cost_express_default',
						'after_id'         => 'shipping_cost_default',
						'name'             => __( 'Default express cost', 'feed-kuantokusta-for-woocommerce-pro' ).' ('.get_woocommerce_currency_symbol().')',
						'type'             => 'text',
						'desc'             => __( 'Default express shipping cost (with tax) per product (can be overriden at the product level)', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip'         => true,
						'id_'              => 'shipping_cost_express_default',
					),
					'documentation'     => array(
						'id'               => 'shipping_cost_express',
						'desc'             => __( 'The product express shipping cost from the KuantoKusta metabox on the product edit screen. If not set, the default value above is used.', 'feed-kuantokusta-for-woocommerce-pro' ),
						'filter'           => true,
					),
					'hooks'             => array(
						'filters' => array(
							'kuantokusta_product_node_default_shipping_express' => array(
								'arguments' => array(
									'$shipping_cost_express',
									'$product',
									'$product_type',
								),
								'desc' => __( 'Filter on the product express shipping cost.', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
							'kuantokusta_product_node_variation_shipping_express' => array(
								'arguments' => array(
									'$shipping_cost_express',
									'$product',
									'$variation',
								),
								'desc' => __( 'Filter on the product variation express shipping cost.', 'feed-kuantokusta-for-woocommerce-pro' ).' '.__( 'If "Include each product variation" is choosen.', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
						),
					),
				),
				//Preparation days minimum
				'preparation_days_min' => array(
					'comparison'       => false,
					'marketplace'      => true,
					'product' => array(
						'id'               => '_kuantokusta_preparation_days_min',
						'label'            => __( 'Minimum preparation time', 'feed-kuantokusta-for-woocommerce-pro' ).' ('.__( 'days', 'feed-kuantokusta-for-woocommerce-pro' ).')',
						//'placeholder'      => sprintf( __( 'Blank for default (%s)', 'feed-kuantokusta-for-woocommerce-pro' ), $this->get_setting( 'preparation_days_min_default' ) ),
						'placeholder'      => __( 'Blank for default (%s)', 'feed-kuantokusta-for-woocommerce-pro' ),
						'placeholder_default' => 'preparation_days_min_default',
						'function'         => 'woocommerce_wp_text_input',
						'extra_attributes' => array(
							'type'          => 'number',
						),
						'custom_attributes' => array(
							'min' => 0,
						),
					),
					'settings'          => array(
						'id'               => 'preparation_days_min_default',
						'after_id'         => 'shipping_cost_default',
						'name'             => __( 'Minimum preparation time', 'feed-kuantokusta-for-woocommerce-pro' ).' ('.__( 'days', 'feed-kuantokusta-for-woocommerce-pro' ).')',
						'type'             => 'number',
						'desc'             => __( 'The default minimum amount of days a product takes to be prepared before it is shipped', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip'         => true,
						'id_'              => 'preparation_days_min_default',
						'custom_attributes' => array(
							'min' => 0,
						),
					),
					'documentation'     => array(
						'id'               => 'preparation_days_min',
						'desc'             => __( 'The minimum amount of days a product takes to be prepared before it is shipped, from the KuantoKusta metabox on the product edit screen. If not set, the default value above is used.', 'feed-kuantokusta-for-woocommerce-pro' ),
						'filter'           => true,
					),
					'hooks'             => array(
						'filters' => array(
							'kuantokusta_product_node_default_preparation_days_min' => array(
								'arguments' => array(
									'$preparation_days_min',
									'$product',
									'$product_type',
								),
								'desc' => __( 'Filter on the product minimum preparation time.', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
							'kuantokusta_product_node_variation_preparation_days_min' => array(
								'arguments' => array(
									'$preparation_days_min',
									'$product',
									'$variation',
								),
								'desc' => __( 'Filter on the product variation minimum preparation time.', 'feed-kuantokusta-for-woocommerce-pro' ).' '.__( 'If "Include each product variation" is choosen.', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
						),
					),
				),
				//Preparation days minimum - On backorder
				'preparation_days_min_backorder' => array(
					'comparison'       => false,
					'marketplace'      => true,
					//'product' => array(
					//),
					'settings'          => array(
						'id'               => 'preparation_days_min_backorder',
						'after_id'         => 'shipping_cost_default',
						'name'             => __( 'Additional minimum preparation time (backorder)', 'feed-kuantokusta-for-woocommerce-pro' ).' ('.__( 'days', 'feed-kuantokusta-for-woocommerce-pro' ).')',
						'type'             => 'number',
						'desc'             => __( 'The additional amount of days a product takes to be prepared before it is shipped, when the stock stauts is set to "On backorder"', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip'         => true,
						'id_'              => 'preparation_days_min_backorder',
						'custom_attributes' => array(
							'min' => 0,
						),
					),
					//'documentation'     => array(
					//),
					//'hooks'             => array(
					//),
				),
				//Delivery days minimum
				'delivery_days_min' => array(
					'comparison'       => false,
					'marketplace'      => true,
					'product' => array(
						'id'               => '_kuantokusta_delivery_days_min',
						'label'            => __( 'Minimum delivery time', 'feed-kuantokusta-for-woocommerce-pro' ).' ('.__( 'days', 'feed-kuantokusta-for-woocommerce-pro' ).')',
						//'placeholder'      => sprintf( __( 'Blank for default (%s)', 'feed-kuantokusta-for-woocommerce-pro' ), $this->get_setting( 'delivery_days_min_default' ) ),
						'placeholder'      => __( 'Blank for default (%s)', 'feed-kuantokusta-for-woocommerce-pro' ),
						'placeholder_default' => 'delivery_days_min_default',
						'function'         => 'woocommerce_wp_text_input',
						'extra_attributes' => array(
							'type'          => 'number',
						),
						'custom_attributes' => array(
							'min' => 0,
						),
					),
					'settings'          => array(
						'id'               => 'delivery_days_min_default',
						'after_id'         => 'shipping_cost_default',
						'name'             => __( 'Minimum delivery time', 'feed-kuantokusta-for-woocommerce-pro' ).' ('.__( 'days', 'feed-kuantokusta-for-woocommerce-pro' ).')',
						'type'             => 'number',
						'desc'             => __( 'The default minimum amount of days the shipping of a product takes', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip'         => true,
						'id_'              => 'delivery_days_min_default',
						'custom_attributes' => array(
							'min' => 0,
						),
					),
					'documentation'     => array(
						'id'               => 'delivery_days_min',
						'desc'             => __( 'The minimum amount of days the shipping of a product takes, from the KuantoKusta metabox on the product edit screen. If not set, the default value above is used.', 'feed-kuantokusta-for-woocommerce-pro' ),
						'filter'           => true,
					),
					'hooks'             => array(
						'filters' => array(
							'kuantokusta_product_node_default_delivery_days_min' => array(
								'arguments' => array(
									'$delivery_days_min',
									'$product',
									'$product_type',
								),
								'desc' => __( 'Filter on the product minimum delivery time.', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
							'kuantokusta_product_node_variation_delivery_days_min' => array(
								'arguments' => array(
									'$delivery_days_min',
									'$product',
									'$variation',
								),
								'desc' => __( 'Filter on the product variation minimum delivery time.', 'feed-kuantokusta-for-woocommerce-pro' ).' '.__( 'If "Include each product variation" is choosen.', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
						),
					),
				),

				//Preparation days maximum - On backorder
				'preparation_days_max_backorder' => array(
					'comparison'       => false,
					'marketplace'      => true,
					//'product' => array(
					//),
					'settings'          => array(
						'id'               => 'preparation_days_max_backorder',
						'after_id'         => 'preparation_days_max_default',
						'name'             => __( 'Additional maximum preparation time (backorder)', 'feed-kuantokusta-for-woocommerce-pro' ).' ('.__( 'days', 'feed-kuantokusta-for-woocommerce-pro' ).')',
						'type'             => 'number',
						'desc'             => __( 'The maximum additional amount of days a product takes to be prepared before it is shipped, when the stock stauts is set to "On backorder"', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip'         => true,
						'id_'              => 'preparation_days_max_backorder',
						'custom_attributes' => array(
							'min' => 0,
						),
					),
					//'documentation'     => array(
					//),
					//'hooks'             => array(
					//),
				),
				//Express delivery days minimum
				'delivery_days_min_express' => array(
					'comparison'       => false,
					'marketplace'      => true,
					'product' => array(
						'id'               => '_kuantokusta_delivery_days_min_express',
						'label'            => __( 'Minimum express delivery time', 'feed-kuantokusta-for-woocommerce-pro' ).' ('.__( 'days', 'feed-kuantokusta-for-woocommerce-pro' ).')',
						//'placeholder'      => sprintf( __( 'Blank for default (%s)', 'feed-kuantokusta-for-woocommerce-pro' ), $this->get_setting( 'delivery_days_min_express_default' ) ),
						'placeholder'      => __( 'Blank for default (%s)', 'feed-kuantokusta-for-woocommerce-pro' ),
						'placeholder_default' => 'delivery_days_min_express_default',
						'function'         => 'woocommerce_wp_text_input',
						'extra_attributes' => array(
							'type'          => 'number',
						),
						'custom_attributes' => array(
							'min' => 0,
						),
					),
					'settings'          => array(
						'id'               => 'delivery_days_min_express_default',
						'after_id'         => 'shipping_cost_default',
						'name'             => __( 'Minimum express delivery time', 'feed-kuantokusta-for-woocommerce-pro' ).' ('.__( 'days', 'feed-kuantokusta-for-woocommerce-pro' ).')',
						'type'             => 'number',
						'desc'             => __( 'The default minimum amount of days the express shipping of a product takes', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip'         => true,
						'id_'              => 'delivery_days_min_express_default',
						'custom_attributes' => array(
							'min' => 0,
						),
					),
					'documentation'     => array(
						'id'               => 'delivery_days_min_express',
						'desc'             => __( 'The minimum amount of days the express shipping of a product takes, from the KuantoKusta metabox on the product edit screen. If not set, the default value above is used.', 'feed-kuantokusta-for-woocommerce-pro' ),
						'filter'           => true,
					),
					'hooks'             => array(
						'filters' => array(
							'kuantokusta_product_node_default_delivery_days_min_express' => array(
								'arguments' => array(
									'$delivery_days_min_express',
									'$product',
									'$product_type',
								),
								'desc' => __( 'Filter on the product minimum express delivery time.', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
							'kuantokusta_product_node_variation_delivery_days_min_express' => array(
								'arguments' => array(
									'$delivery_days_min_express',
									'$product',
									'$variation',
								),
								'desc' => __( 'Filter on the product variation minimum express delivery time.', 'feed-kuantokusta-for-woocommerce-pro' ).' '.__( 'If "Include each product variation" is choosen.', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
						),
					),
				),
				//Express delivery days maximum
				'delivery_days_max_express' => array(
					'comparison'       => false,
					'marketplace'      => true,
					'product' => array(
						'id'               => '_kuantokusta_delivery_days_max_express',
						'label'            => __( 'Maximum express delivery time', 'feed-kuantokusta-for-woocommerce-pro' ).' ('.__( 'days', 'feed-kuantokusta-for-woocommerce-pro' ).')',
						//'placeholder'      => sprintf( __( 'Blank for default (%s)', 'feed-kuantokusta-for-woocommerce-pro' ), $this->get_setting( 'delivery_days_max_express_default' ) ),
						'placeholder'      => __( 'Blank for default (%s)', 'feed-kuantokusta-for-woocommerce-pro' ),
						'placeholder_default' => 'delivery_days_max_express_default',
						'function'         => 'woocommerce_wp_text_input',
						'extra_attributes' => array(
							'type'          => 'number',
						),
						'custom_attributes' => array(
							'min' => 0,
						),
					),
					'settings'          => array(
						'id'               => 'delivery_days_max_express_default',
						'after_id'         => 'delivery_days_max_default',
						'name'             => __( 'Maximum express delivery time', 'feed-kuantokusta-for-woocommerce-pro' ).' ('.__( 'days', 'feed-kuantokusta-for-woocommerce-pro' ).')',
						'type'             => 'number',
						'desc'             => __( 'The default maximum amount of days the express shipping of a product takes', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip'         => true,
						'id_'              => 'delivery_days_max_express_default',
						'custom_attributes' => array(
							'min' => 0,
						),
					),
					'documentation'     => array(
						'id'               => 'delivery_days_max_express',
						'desc'             => __( 'The maximum amount of days the express shipping of a product takes, from the KuantoKusta metabox on the product edit screen. If not set, the default value above is used.', 'feed-kuantokusta-for-woocommerce-pro' ),
						'filter'           => true,
					),
					'hooks'             => array(
						'filters' => array(
							'kuantokusta_product_node_default_delivery_days_max_express' => array(
								'arguments' => array(
									'$delivery_days_max_express',
									'$product',
									'$product_type',
								),
								'desc' => __( 'Filter on the product maximum express delivery time.', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
							'kuantokusta_product_node_variation_delivery_days_max_express' => array(
								'arguments' => array(
									'$delivery_days_max_express',
									'$product',
									'$variation',
								),
								'desc' => __( 'Filter on the product variation maximum express delivery time.', 'feed-kuantokusta-for-woocommerce-pro' ).' '.__( 'If "Include each product variation" is choosen.', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
						),
					),
				),
				//Images
				'image_url_x' => array(
					'comparison' => false,
					'marketplace' => true,
					'product'           => false,
					'settings'          => false,
					'documentation'     => array(
						'id'               => 'image_url_x',
						'desc'             => __( 'The product additional image urls (x = 2 to 5).', 'feed-kuantokusta-for-woocommerce-pro' ),
						'filter'           => true,
						'comparison'       => false,
						'marketplace'      => true,
					),
					'hooks'             => array(
						'filters' => array(
							'kuantokusta_product_node_default_image_x' => array(
								'arguments' => array(
									'$brand_ref',
									'$product',
									'$product_type',
								),
								'desc' => __( 'Filter on the product additional image urls (x = 2 to 5).', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
							'kuantokusta_product_node_variation_image_x' => array(
								'arguments' => array(
									'$brand_ref',
									'$product',
									'$variation',
								),
								'desc' => __( 'Filter on the product variation additional image urls (x = 2 to 5).', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
						),
					),
				),
				//Categories
				'cat_section_title' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'         => 'cat_section_title',
						'after_id'   => false,
						'name'       => __( 'Categories', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'       => 'title',
						'desc'       => __( 'Replace the native WooCommerce category with another source of data.', 'feed-kuantokusta-for-woocommerce-pro' ),
					),
					'documentation' => false,
					'hooks'         => false,
				),

				'category_origin' => array(
					'comparison'    => true,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'       => 'category_origin',
						'after_id' => false,
						'name'     => __( 'Get category from', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'     => 'text', //We're using a text field and not a select because WooCommerce does not allow to sae values that are not set as field options
						'desc'     => __( 'Where to get the category from', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip' => true,
						'id_'      => 'category_origin',
						'class'    => 'kk_field_origins',
						'custom_attributes' => array(
							'data-defaultlabel' => __( 'Product category', 'feed-kuantokusta-for-woocommerce-pro' ),
						),
					),
					'documentation' => false,
					'hooks'         => false,
				),

				'cat_section_end' => array(
					'comparison'    => false,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'         => 'cat_section_end',
						'after_id'   => false,
						'type'       => 'sectionend',
					),
					'documentation' => false,
					'hooks'         => false,
				),
				//Custom attributes
				'ca_section_title' => array(
					'comparison'    => false,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'         => 'ca_section_title',
						'after_id'   => false,
						'name'       => __( 'Custom attributes', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'       => 'title',
						'desc'       => __( 'If you need to send custom attributes to KuantoKusta, you can choose which custom fields or WooCommerce product attributes to include in the feed. Do not use this feature unless you are absolutely sure you need to send additional information.', 'feed-kuantokusta-for-woocommerce-pro' ),
					),
					'documentation' => false,
					'hooks'         => false,
				),
				'ca_attributes' => array(
					'comparison'    => false,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'         => 'ca_attributes',
						'after_id'   => false,
						'name'       => __( 'Product attributes', 'feed-kuantokusta-for-woocommerce-pro' ),
						'type'		 => 'multiselect',
						'desc'		 => __( 'Select which WooCommerce product attributes should be included in the KuantoKusta feed', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip'	 => true,
						'id_'		 => 'ca_attributes',
						'options'	 => $this->wc_get_attribute_taxonomies(),
						'class'      => 'wc-enhanced-select',
					),
					'documentation'     => array(
						'id'               => 'product_attribute_x',
						'desc'             => __( 'The product attribute (x = attribute name).', 'feed-kuantokusta-for-woocommerce-pro' ),
						'filter'           => true,
						'comparison'       => false,
						'marketplace'      => true,
					),
					'hooks'             => array(
						'filters' => array(
							'kuantokusta_product_node_default_product_attribute_x' => array(
								'arguments' => array(
									'$brand_ref',
									'$product',
									'$product_type',
								),
								'desc' => __( 'Filter on the product attribute value (x = attribute name).', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
							'kuantokusta_product_node_variation_product_attribute_x' => array(
								'arguments' => array(
									'$brand_ref',
									'$product',
									'$variation',
								),
								'desc' => __( 'Filter on the product variation attribute value (x = attribute name).', 'feed-kuantokusta-for-woocommerce-pro' ),
							),
						),
					),
				),
				'ca_section_end' => array(
					'comparison'    => false,
					'marketplace'   => true,
					'product'       => false,
					'settings'      => array(
						'id'         => 'ca_section_end',
						'after_id'   => false,
						'type'       => 'sectionend',
					),
					'documentation' => false,
					'hooks'         => false,
				),
			) );
		}
	}

	/* Get product attributes */
	public function wc_get_attribute_taxonomies() {
		$att = array();
		$attributes = wc_get_attribute_taxonomies();
		foreach ( $attributes as $attribute ) {
			$att[ $attribute->attribute_name ] =  $attribute->attribute_label;
		}
		return $att;
	}

	/* Get field possible origins */
	public function get_field_origins() {
		if ( ! $this->field_origins ) {
			//$time_start = microtime(true);
			$options = array();
			//Our field
			$options['field'] = __( 'Default', 'feed-kuantokusta-for-woocommerce-pro' );
			//Taxonomies
			$taxonomies = get_object_taxonomies( 'product', 'objects' );
			foreach ( $taxonomies as $taxonomy ) {
				$options['taxon_'.$taxonomy->name] = sprintf(
					'%1$s: %2$s (%3$s)',
					__( 'Taxonomy', 'feed-kuantokusta-for-woocommerce-pro' ),
					$taxonomy->labels->singular_name,
					$taxonomy->name
				);
			}
			//Custom fields - CRUD Compatible but VERY slow
			if ( apply_filters( 'kuantokusta_field_origins_load_custom_fields', true ) ) {
				/*$posts = get_posts( array(
					'post_type'   => 'product',
					'orderby'     => 'rand', //We need a good sample of products
					'order'       => 'ASC',
					'numberposts' => 999 //We need a good sample of products
				) );
				if ( ! empty( $posts ) ) {
					foreach ( $posts as $post ) {
						$post_meta = get_post_meta( $post->ID, '' );
						if ( ! empty( $post_meta ) ) {
							foreach ( $post_meta as $meta_key => $meta_value ) {
								if ( ! isset( $options['metak_'.$meta_key] ) ) {
									$options['metak_'.$meta_key] = sprintf(
										'%1$s: %2$s',
										__( 'Custom field', 'feed-kuantokusta-for-woocommerce-pro' ),
										$meta_key
									);
								}
							}
						}
					}
				}*/
				/* Not CRUD compatible but fast - This could be faster if we only loaded it via ajax on the options page... */
				global $wpdb;
				$sql = "SELECT DISTINCT( pm.meta_key ) FROM $wpdb->postmeta AS pm, $wpdb->posts AS p WHERE pm.post_id=p.ID AND pm.meta_value!='' AND p.post_type='product' AND p.post_status='publish' ORDER BY pm.meta_key";
				if ( $results = $wpdb->get_results( $sql ) ) {
					foreach ( $results as $result ) {
						$options['metak_'.$result->meta_key] = sprintf(
							'%1$s: %2$s',
							__( 'Custom field', 'feed-kuantokusta-for-woocommerce-pro' ),
							$result->meta_key
						);
					}
				}
			}

			//Cache it
			$this->field_origins = $options;
			//$time_end = microtime(true);
			//$time = $time_end - $time_start;
			//echo "get_field_origins in $time seconds\n";
		}
		return $this->field_origins;
	}

	/* PRO Javascript to populate field_origins fields */
	public function settings_page_footer() {
		?>
		<script type="text/javascript">
		jQuery(function($) {

			var block_settings = {
				message: null,
				overlayCSS: {
					background: '#fff',
					opacity: 0.6
				}
			};
			//Get field_origins fields by class name
			var field_origins_fields = [];
			$( '.kk_field_origins' ).each(function() {
				field_origins_fields.push( $( this ).attr( 'id' ) );
				//Disable the field until we get the options via ajax
				$( this ).prop( 'disabled', true );
				//Block the field TR
				$( this ).parent().parent().block( block_settings );
			});
			if ( field_origins_fields.length > 0 ) {
				//Block the form submit
				$( 'p.submit' ).block( block_settings );
				//Ajax
				$.ajax({
					method:   'POST',
					dataType: 'json',
					url:      woocommerce_admin.ajax_url,
					data:     {
						action:   'kk_field_origins',
						security: '<?php echo wp_create_nonce( 'kk_field_origins_ajax_nonce' ); ?>',
						fields:   field_origins_fields
					},
					success: function( response ) {
						if ( response.success ) {
							$.each( response.data.values, function( field, value ) {
								//Change the original text field ID
								$( '#'+field ).attr( 'id', field+'_' );
								//Add a select field with the original ID
								$( '<select name="'+field+'" id="'+field+'" class="kk_field_origins_select"></select>' ).insertAfter( '#'+field+'_' );
								$.each( response.data.field_origins, function( option_value, option_label ) {
									if ( option_value == 'field' ) {
										option_label = option_label + ': '+ $( '#'+field+'_' ).data( 'defaultlabel' );
									}
									$( '#'+field ).append( $( '<option>', { 
										value: option_value,
										text : option_label 
									}));
								});
								<?php if ( $this->bigbuy_active ) { ?>
								if ( $( '#'+field ).attr( 'id' ) == 'wc_feed_kuantokusta_ean_origin' ) {
									$( '#'+field ).append( $( '<option>', { 
										value: 'bigbu_refdata',
										text : '<?php _e( 'BigBuy: reference data table' , 'feed-kuantokusta-for-woocommerce-pro' ); ?>' 
									}));
								}
								<?php } ?>
								//Remove the original text field
								$( '#'+field+'_' ).remove();
								//Set the value and unblock it
								if ( value == '' ) value = 'field';
								$( '#'+field ).val( value );
								$( '#'+field ).parent().parent().unblock();
							});
							//Trigger change to fire other events
							$.each( response.data.values, function( field, value ) {
								$( '#'+field ).trigger( 'change' );
							});
						} else {
							alert( '<?php _e( 'Error getting field origins, please contact support', 'feed-kuantokusta-for-woocommerce-pro' ); ?>' );
						}
						$( 'p.submit' ).unblock();
					}
				});
			}
			$( '#kk_settings' ).on( 'change', '.kk_field_origins_select', function() {
				if ( $( this ).val() == 'field' ) {
					$( '#' + this.id + '_default_to_field' ).parent().parent().hide();
				} else {
					$( '#' + this.id + '_default_to_field' ).parent().parent().show();
				}
			});

			//Check updates
			if ( $( '#kk_api_version_update' ).length ) {
				var plugin = $( '#kk_api_version_update' ).data( 'plugin' );
				var interval = setInterval( function() {
					$( '#kk_api_version_update' ).append( '.' );
				}, 100 );
				var data = {
					'action': '<?php echo WC_Feed_KuantoKusta()->id; ?>_pro_check_update_version',
					'plugin': plugin
				};
				jQuery.post( ajaxurl, data, function( response ) {
					clearInterval( interval );
					$( '#kk_api_version_update' ).html( response );
				});
			}

		});
		</script>
		<?php
	}

	/* Field origins AJAX */
	public function wp_ajax_field_origins() {
		if ( wp_verify_nonce( $_POST['security'], 'kk_field_origins_ajax_nonce' ) ) {
			$response = array(
				'values' => array()
			);
			//Get fields values on the database
			if ( isset( $_POST['fields'] ) && is_array( $_POST['fields'] ) && count( $_POST['fields'] ) > 0 ) {
				foreach ( $_POST['fields'] as $key ) {
					$response['values'][$key] = $this->get_setting( str_replace( WC_Feed_KuantoKusta()->id.'_', '', $key ) );
				}
			}
			//Get field origins
			$response['field_origins'] = $this->get_field_origins();
			//Return it
			wp_send_json_success( $response );
		} else {
			wp_send_json_error();
		}
	}


	/* Add settings link to plugin actions */
	public function add_settings_link( $links ) {
		$action_links = array(
			'kk_settings' => '<a href="admin.php?page=wc-settings&amp;tab=kuantokusta">' . __( 'Settings', 'feed-kuantokusta-for-woocommerce-pro' ) . '</a>',
		);
		return array_merge( $action_links, $links );
	}

	/* Settings tab */
	public function settings_tab_title( $title ) {
		$title .= ' ('.__( 'PRO', 'feed-kuantokusta-for-woocommerce-pro' ).') ';
		return $title;
	}
	public function settings_title( $title ) {
		$title .= ' + '.sprintf(
			__( 'PRO add-on (%s)', 'feed-kuantokusta-for-woocommerce-pro' ),
			$this->version
		);
		return $title;
	}

	/* Add Documentation URL information */
	public function documentation_before_fields() {
		include( dirname( __FILE__ ) . '/admin/settings-page-documentation-before-fields.php' );
	}

	/* Global settings */
	public function wc_settings_kuantokusta_settings( $settings ) {
		//$this->init_fields();
		$new_settings = array();
		//Add fields in between the others
		foreach ( $settings as $key => $setting ) {
			$new_settings[ $key ] = $setting;
			foreach ( $this->fields as $key2 => $field ) {
				if ( $field['settings'] ) {
					if ( $field[WC_Feed_KuantoKusta()->mode] ) {
						if ( $field['settings']['after_id'] == $key ) {
							$new_settings[ $field['settings']['id'] ] = array();
							foreach ( $field['settings'] as $key3 => $value3 ) {
								$new_settings[ $field['settings']['id'] ][ $key3 ] = $value3;
							}
						}
					}
				}
			}
		}
		//Add fields at the end
		foreach ( $this->fields as $key2 => $field ) {
			if ( $field['settings'] ) {
				if ( $field[WC_Feed_KuantoKusta()->mode] ) {
					if ( ! $field['settings']['after_id'] ) {
						$new_settings[ $field['settings']['id'] ] = array();
						foreach ( $field['settings'] as $key3 => $value3 ) {
							$new_settings[ $field['settings']['id'] ][ $key3 ] = $value3;
						}
					}
				}
			}
		}
		return $new_settings;
	}

	/* Add our own product fields */
	public function product_fields() {
		?>
		<p class="kuantokusta-title">
			<strong><?php _e( 'PRO add-on', 'feed-kuantokusta-for-woocommerce-pro' ); ?></strong>
		</p>
		<?php
		foreach ( $this->fields as $key => $field ) {
			if ( isset( $field['product'] ) && $field['product'] ) {
				if ( $field[WC_Feed_KuantoKusta()->mode] ) {
					$function  = $field['product']['function'];
					$array = array(
						'id'          => $field['product']['id'],
						'label'       => $field['product']['label'],
						'placeholder' => $field['product']['placeholder'],
					);
					if ( stristr( $field['product']['placeholder'], '%s' ) && isset( $field['product']['placeholder_default'] ) ) {
						$array['placeholder'] = sprintf(
							$field['product']['placeholder'],
							$this->get_setting( $field['product']['placeholder_default'] )
						);
					}
					foreach ( $field['product']['extra_attributes'] as $key2 => $temp ) {
						$array[$key2] = $temp;
					}
					if ( isset( $field['product']['custom_attributes'] ) ) $array['custom_attributes'] = $field['product']['custom_attributes'];
					$function( $array );
				}
			}
		}
	}
	public function process_product_fields( $meta ) {
		foreach ( $this->fields as $key => $field ) {
			if ( isset( $field['product'] ) && $field['product'] ) {
				$meta[$field['product']['id']] = trim( $_POST[$field['product']['id']] ) != '' ? wc_clean( $_POST[$field['product']['id']] ) : '';
			}
		}
		return $meta;
	}

	/* Add our own variation fields */
	public function woocommerce_product_after_variable_attributes( $loop, $variation_data, $variation ) {
		global $thepostid;
		if ( ! isset( $thepostid ) ) {
			$thepostid = $variation->post_parent;
		}
		$product = wc_get_product( $thepostid );
		$variation = wc_get_product( $variation->ID );
		?>
		<div class="clear"></div>
		<div id="kuantokusta_variation_<?php echo $loop; ?>">
			<br/>
			<hr/>
			<p class="form-field form-row form-row-full kuantokusta_plugin_title">
				<strong><?php echo apply_filters( 'kuantokusta_settings_tab_title', __( 'KuantoKusta', 'feed-kuantokusta-for-woocommerce-pro' ) ); ?></strong>
			</p>
			<?php
			//EAN - MISSING REMOVE META IF WOO EAN IS SET
			if (
				version_compare( WC_VERSION, '9.2', '<' )
				||
				(
					version_compare( WC_VERSION, '9.2', '>=' )
					&&
					empty( $variation->get_global_unique_id() )
					&&
					! empty( $variation->get_meta( '_kuantokusta_ean' ) )
				)
			) {
				$ean_description     = __( 'EAN / UPC', 'feed-kuantokusta-for-woocommerce-pro' ).' - '.__( 'If different from parent product', 'feed-kuantokusta-for-woocommerce-pro' );
				$ean_description_tip = true;
				if ( version_compare( WC_VERSION, '9.2', '>=' ) ) {
					$ean_description     = '<span style="color: red">' . esc_html__( 'The EAN / UPC should now be set on the WooCommerce "GTIN, UPC, EAN or ISBN" field above - once you fill that field, this one will be removed', 'feed-kuantokusta-for-woocommerce' ) . '</span>';
					$ean_description_tip = false;
				}
				woocommerce_wp_text_input(
					array(
						'id'            => "variable_kuantokusta_ean{$loop}",
						'name'          => "variable_kuantokusta_ean[{$loop}]",
						'value'         => $variation->get_meta( '_kuantokusta_ean' ),
						'placeholder'   => $product->get_meta( '_kuantokusta_ean' ) != '' ? sprintf( __( 'Blank for parent product (%s)', 'feed-kuantokusta-for-woocommerce-pro' ), $product->get_meta( '_kuantokusta_ean' ) ) : __( 'Barcode', 'feed-kuantokusta-for-woocommerce-pro' ),
						'label'         => __( 'EAN / UPC', 'feed-kuantokusta-for-woocommerce-pro' ),
						'desc_tip'      => $ean_description_tip,
						'description'   => $ean_description,
						'type'          => 'text',
						'wrapper_class' => 'form-row form-row-first',
					)
				);
			} else {
				?>
				<p class="form-field variable_kuantokusta_ean{$loop}_field form-row form-row-first">
					<label>
						<?php esc_html_e( 'EAN / UPC', 'feed-kuantokusta-for-woocommerce' ); ?>
					</label>
					<br/>
					<?php esc_html_e( 'The EAN / UPC is now set on the WooCommerce "GTIN, UPC, EAN or ISBN" field above', 'feed-kuantokusta-for-woocommerce' ); ?>
				</p>
				<?php
			}
			//Brand SKU
			woocommerce_wp_text_input(
				array(
					'id'            => "variable_kuantokusta_brand_sku{$loop}",
					'name'          => "variable_kuantokusta_brand_sku[{$loop}]",
					'value'         => $variation->get_meta( '_kuantokusta_brand_sku' ),
					'placeholder'   => $product->get_meta( '_kuantokusta_brand_sku' ) != '' ? sprintf( __( 'Blank for parent product (%s)', 'feed-kuantokusta-for-woocommerce-pro' ), $product->get_meta( '_kuantokusta_brand_sku' ) ) : __( 'Brand SKU / MPN', 'feed-kuantokusta-for-woocommerce-pro' ),
					'label'         => __( 'Brand SKU / MPN', 'feed-kuantokusta-for-woocommerce-pro' ),
					'desc_tip'      => true,
					'description'   => __( 'Brand SKU / MPN', 'feed-kuantokusta-for-woocommerce-pro' ).' - '.__( 'If different from parent product', 'feed-kuantokusta-for-woocommerce-pro' ),
					'type'          => 'text',
					'wrapper_class' => 'form-row form-row-last',
				)
			);
			?>
			<div class="clear"></div>
		</div>
		<?php
	}
	public function woocommerce_save_product_variation( $variation_id, $index ) {
		$variation = wc_get_product( $variation_id );
		// EAN
		$ean = isset( $_POST['variable_kuantokusta_ean'][ $index ] ) && ! empty( $_POST['variable_kuantokusta_ean'][ $index ] ) ? wc_clean( $_POST['variable_kuantokusta_ean'][ $index ] ) : '';
		if ( version_compare( WC_VERSION, '9.2', '>=' ) && ! empty( $_POST['variable_global_unique_id'][ $index ] ) ) {
			// If the core field is filled in, remove ours from the database
			$variation->delete_meta_data( '_kuantokusta_ean' );
		} else {
			$variation->update_meta_data( '_kuantokusta_ean', $ean );
		}
		// Brand SKU / MPN
		if ( isset( $_POST['variable_kuantokusta_brand_sku'][ $index ] ) ) {
			$variation->update_meta_data( '_kuantokusta_brand_sku', wc_clean( $_POST['variable_kuantokusta_brand_sku'][ $index ] ) );
		}
		$variation->save();
	}

	/* Get product shipping cost - express - Still not set per variation */
	public function get_product_shipping_cost_express( $product ) {
		$shipping_cost_express = $product->get_meta( '_kuantokusta_shipping_express' );
		// We do not use empty() because the shop owner might want to offer free shipping
		if ( trim( $shipping_cost_express ) == '' ) $shipping_cost_express = $this->get_setting( 'shipping_cost_express_default' );
		return $shipping_cost_express;
	}

	/* Get product minimum preparation time */
	public function get_product_preparation_days_min( $product ) {
		$preparation_days_min = $product->get_meta( '_kuantokusta_preparation_days_min' );
		if ( empty( $preparation_days_min ) ) $preparation_days_min = $this->get_setting( 'preparation_days_min_default' );
		if ( intval( $this->get_setting( 'preparation_days_min_backorder' ) ) > 0 && $product->is_on_backorder() ) {
			$preparation_days_min = intval( $preparation_days_min ) + intval( $this->get_setting( 'preparation_days_min_backorder' ) );
		}
		return $preparation_days_min;
	}

	/* Add product maximum preparation time if on backorder */
	public function get_product_preparation_days_max_backorder( $preparation_days_max, $product, $product_type ) {
		if ( intval( $this->get_setting( 'preparation_days_max_backorder' ) ) > 0 && $product->is_on_backorder() ) {
			$preparation_days_max = intval( $preparation_days_max ) + intval( $this->get_setting( 'preparation_days_max_backorder' ) );
		}
		return $preparation_days_max;
	}

	/* Add product variation maximum preparation time if on backorder */
	public function get_product_variation_preparation_days_max_backorder( $preparation_days_max, $product, $variation ) {
		if ( intval( $this->get_setting( 'preparation_days_max_backorder' ) ) > 0 && $variation->is_on_backorder() ) {
			$preparation_days_max = intval( $preparation_days_max ) + intval( $this->get_setting( 'preparation_days_max_backorder' ) );
		}
		return $preparation_days_max;
	}

	/* Add product variation EAN */
	public function get_product_variation_variation_ean( $ean, $product, $variation ) {
		//Get from variation, if it exists
		$variation_ean = WC_Feed_KuantoKusta()->get_product_ean( $variation );
		if ( trim( $variation_ean ) != '' ) {
			$ean = trim( $variation_ean );
		}
		//And then check for other origins
		return $this->get_field_from_origin( $ean, 'ean_origin', $product, $variation );
	}

	/* Get product minimum preparation time */
	public function get_product_variation_preparation_days_min( $product, $variation ) {
		$preparation_days_min = $product->get_meta( '_kuantokusta_preparation_days_min' );
		if ( empty( $preparation_days_min ) ) $preparation_days_min = $this->get_setting( 'preparation_days_min_default' );
		if ( intval( $this->get_setting( 'preparation_days_min_backorder' ) ) > 0 && $variation->is_on_backorder() ) {
			$preparation_days_min = intval( $preparation_days_min ) + intval( $this->get_setting( 'preparation_days_min_backorder' ) );
		}
		return $preparation_days_min;
	}

	/* Get product minimum delivery time */
	public function get_product_delivery_days_min( $product ) {
		$delivery_days_min = $product->get_meta( '_kuantokusta_delivery_days_min' );
		if ( empty( $delivery_days_min ) ) $delivery_days_min = $this->get_setting( 'delivery_days_min_default' );
		return $delivery_days_min;
	}

	/* Get product minimum express delivery time */
	public function get_product_express_delivery_days_min( $product ) {
		$delivery_days_min_express = $product->get_meta( '_kuantokusta_delivery_days_min_express' );
		if ( empty( $delivery_days_min_express ) ) $delivery_days_min_express = $this->get_setting( 'delivery_days_min_express_default' );
		return $delivery_days_min_express;
	}

	/* Get product maximum express delivery time */
	public function get_product_express_delivery_days_max( $product ) {
		$delivery_days_max_express = $product->get_meta( '_kuantokusta_delivery_days_max_express' );
		if ( empty( $delivery_days_max_express ) ) $delivery_days_max_express = $this->get_setting( 'delivery_days_max_express_default' );
		return $delivery_days_max_express;
	}

	/* Get additional images */
	public function get_product_additional_images( $product ) {
		$images = array();
		$image_ids = $product->get_gallery_image_ids();
		$i = 2;
		if ( ! empty( $image_ids ) ) {
			for ( $i = 2; $i <= 5 ; $i++ ) {
				if ( isset( $image_ids[ $i-2 ] ) ) {
					$images[$i] = $image_ids[ $i-2 ] > 0 ? wp_get_attachment_url( $image_ids[ $i-2 ] ) : '';
				} else {
					break;
				}
			}
		}
		while ( $i <= 5 ) {
			$images[$i] = '';
			$i++;
		}
		return $images;
	}

	/* Get attributes */
	public function get_product_attributes( $product ) {
		$atts = array();
		$attributes = $this->get_setting( 'ca_attributes' );
		if ( is_array( $attributes ) && count( $attributes ) > 0) {
			foreach ( $attributes as $attribute ) {
				$atts[$attribute] = $product->get_attribute( $attribute );
				if ( $atts[$attribute] === '' && $product->get_type() === 'variation' ) {
					$parent_product = wc_get_product( $product->get_parent_id() );
					$product_attributes = $parent_product->get_attributes();
					if ( isset( $product_attributes[ 'pa_' . $attribute ] ) ) {
						if ( ! $product_attributes[ 'pa_' . $attribute ]->get_variation() ) {
							// Attribute is from parent product only, not used for variations
							$atts[$attribute] = $parent_product->get_attribute( $attribute );
						}
					}
				}
			}
		}
		return $atts;
	}

	/* Get EAN from BigBuy Reference data table */
	private function get_ean_from_bigbuy_reference_data( $product, $variation ) {
		global $wpdb;
		if ( $variation ) {
			$sku = $variation->get_sku();
			if ( ! empty( $sku ) ) {
				$sql = $wpdb->prepare(
					"SELECT * FROM ".$wpdb->prefix."mipconnector_reference_data WHERE product_id IS NOT NULL AND variation_id  IS NOT NULL AND ean IS NOT NULL AND reference = %s",
					array( $sku )
				);
				if ( $results = $wpdb->get_results( $sql ) ) {
					$ean = trim( $results[0]->ean );
					if ( $ean === '0' ) $ean = ''; // We've seen some "zeros"
					return $ean;
				}
			}
			// Default to product
			return $this->get_ean_from_bigbuy_reference_data( $product, null );
		} else {
			$sku = $product->get_sku();
			if ( ! empty( $sku ) ) {
				$sql = $wpdb->prepare(
					"SELECT * FROM ".$wpdb->prefix."mipconnector_reference_data WHERE product_id IS NOT NULL AND variation_id IS NULL AND ean IS NOT NULL AND reference = %s",
					array( $sku )
				);
				if ( $results = $wpdb->get_results( $sql ) ) {
					$ean = trim( $results[0]->ean );
					if ( $ean === '0' ) $ean = ''; // We've seen some "zeros"
					return $ean;
				}
			}
		}
		return '';
	}

	/* Get field from taxonomy or custom field */
	public function get_field_from_origin( $value, $setting, $product, $variation = null, $deep_taxonomy = false ) {
		$new_value = false;
		switch ( substr( $this->get_setting( $setting ), 0, 5 ) ) {
			case 'taxon':
				$new_value = '';
				//Only search on product, even if it's a variation
				$taxonomy = substr( $this->get_setting( $setting ), 6 ); //Remove 'taxon_'
				if ( $deep_taxonomy ) {
					if ( $terms = wc_get_product_terms( $product->get_id(), $taxonomy, array( 'orderby' => 'parent', 'order' => 'DESC' ) ) ) {
						if ( count( $terms ) == 1 ) {
							$new_value = trim( $terms[0]->name );
						} else {
							$return_value = '';
							// From class-wc-breadcrumb.php
							$main_term = apply_filters( 'woocommerce_breadcrumb_main_term', $terms[0], $terms );
							$ancestors = array_reverse( get_ancestors( $main_term->term_id, $taxonomy ) );
							foreach ( $ancestors as $ancestor ) {
								$ancestor = get_term( $ancestor, $taxonomy );
								if ( ! is_wp_error( $ancestor ) && $ancestor ) {
									$return_value .= trim( $ancestor->name ).' > ';
								}
							}
							$return_value .= trim( $main_term->name );
							$new_value = $return_value;
						}
					}
				} else {
					if ( $terms = wc_get_product_terms( $product->get_id(), $taxonomy ) ) {
						foreach ( $terms as $term ) {
							$new_value = esc_html( $term->name ); //Return first one
						}
					}
				}
				break;
			case 'metak':
				$new_value = '';
				$field = substr( $this->get_setting( $setting ), 6 ); //Remove 'metak_'
				$function = 'get_'.$field;
				$function = str_replace( 'get__', 'get_', $function );
				if ( $variation ) {
					if ( is_callable( array( $variation, $function ) ) ) {
						$new_value_temp = $variation->{$function}();
					} else {
						$new_value_temp = $variation->get_meta( $field );
					}
					if ( ! empty( $new_value_temp ) ) $new_value = $new_value_temp; //If not, search on the product (most probably)
				}
				if (
					(
						//Variation still without a value, go to product
						$variation
						&&
						$new_value === false
					)
					||
					(
						//Not a variation, go to product
						! $variation
					)
				) {
					if ( is_callable( array( $product, $function ) ) ) {
						$new_value = $product->{$function}();
					} else {
						$new_value = $product->get_meta( $field );
					}
				}
				break;
			case 'bigbu':
				if ( $this->bigbuy_active && $setting == 'ean_origin' ) {
					$new_value = $this->get_ean_from_bigbuy_reference_data( $product, $variation );
				}
				break;
			case 'field':
			default:
				//Do nothing - $new_value is still false
				break;
		}
		if ( $new_value !== false ) {
			//Default to original value?
			if ( empty( $new_value ) && $this->get_setting( $setting.'_default_to_field' ) == 'yes' ) {
				return $value;
			} else {
				return $new_value;
			}
		}
		return $value;
	}

	/* Get product brand */
	public function get_product_brand( $brand, $product ) {
		$brand = trim( $this->get_field_from_origin( $brand, 'brand_origin', $product ) );
		if ( empty( $brand ) && ! empty( trim(  $this->get_setting( 'brand_default_value' ) ) ) ) {
			$brand = trim(  $this->get_setting( 'brand_default_value' ) );
		}
		return $brand;
	}
	public function get_product_variation_brand( $brand, $product, $variation ) {
		$brand = trim( $this->get_field_from_origin( $brand, 'brand_origin', $product, $variation ) );
		if ( empty( $brand ) && ! empty( trim(  $this->get_setting( 'brand_default_value' ) ) ) ) {
			$brand = trim(  $this->get_setting( 'brand_default_value' ) );
		}
		return $brand;
	}

	/* Get product EAN */
	public function get_product_ean( $ean, $product ) {
		return $this->get_field_from_origin( $ean, 'ean_origin', $product );
	}

	/* Get product category */
	public function get_product_category( $category, $product ) {
		return $this->get_field_from_origin( $category, 'category_origin', $product, null, true );
	}
	public function get_product_variation_category( $category, $product, $variation ) {
		return $this->get_field_from_origin( $category, 'category_origin', $product, $variation, true );
	}

	/* Helper function to make sure variation always is returned with attributes */
	public function return_true() {
		return true;
	}
	/* Get variation title - full, forcing attributes in case someone return false to '' */
	public function get_product_variation_title( $title, $product, $variation ) {
		if ( ! apply_filters( 'woocommerce_product_variation_title_include_attributes', true, $variation ) ) {
			if ( apply_filters( 'kuantokusta_variation_should_force_attributes_on_name', true ) ) add_filter( 'woocommerce_product_variation_title_include_attributes', array( $this, 'return_true' ) ); //Not using __return_true because we could be removing someone else filter below
			$variation = wc_get_product( $variation->get_id() );
			$title     = $variation->get_name();
			if ( apply_filters( 'kuantokusta_variation_should_force_attributes_on_name', true ) ) remove_filter( 'woocommerce_product_variation_title_include_attributes', array( $this, 'return_true' ) );
		}
		return $title;
	}
	/* Append description to variation titles? */
	public function variation_title_append_description( $bool, $product, $variation ) {
		if ( $this->get_setting( 'variable_append_description' ) == 'no' ) {
			return false;
		}
		return $bool;
	}

	/* Discount Rules for WooCommerce compatibility - https://wordpress.org/plugins/woo-discount-rules/ */
	public function woo_discount_rules_default_current_price( $price, $product, $product_type ) {
		return $this->woo_discount_rules_discounted_price( $price, $product );
	}
	public function woo_discount_rules_variation_current_price( $price, $product, $variation ) {
		return $this->woo_discount_rules_discounted_price( $price, $variation );
	}
	private function woo_discount_rules_discounted_price( $price, $product ) {
		/*if ( $prices = \Wdr\App\Controllers\ManageDiscount::calculateInitialAndDiscountedPrice( $product, 1 ) ) {
			if ( isset( $prices['discounted_price_with_tax'] ) && floatval( $prices['discounted_price_with_tax'] ) > 0 ) {
				$price = floatval( $prices['discounted_price_with_tax'] );
			}
		}*/
		if ( $discount_price = apply_filters( 'advanced_woo_discount_rules_get_product_discount_price_from_custom_price', $product->get_price(), $product, 1, 0, 'all', true, false ) ) {
			if ( isset( $discount_price['discounted_price_with_tax'] ) && floatval( $discount_price['discounted_price_with_tax'] ) > 0 ) {
				return floatval( $discount_price['discounted_price_with_tax'] );
			}
		}
		return $price;
	}

	/* Add fields to feed */
	public function product_node_default_xml_fields( $xml_fields, $product, $product_type ) {
		if ( $this->license_validated() ) {
			if (  WC_Feed_KuantoKusta()->mode == 'marketplace' ) {
				//Brand SKU / MPN
				$brand_sku = apply_filters( 'kuantokusta_product_node_default_brand_ref', $this->get_field_from_origin( $product->get_meta( '_kuantokusta_brand_sku' ), 'brand_ref_origin', $product ), $product, $product_type );
				$xml_fields['brand_ref'] = array(
					'value' => trim( $brand_sku ),
					'cdata' => true,
				);
				//Shipping cost (express)
				$shipping_cost_express = apply_filters( 'kuantokusta_product_node_default_shipping_express', $this->get_product_shipping_cost_express( $product ), $product, $product_type );
				$xml_fields['shipping_cost_express'] = array(
					'value' => ! empty( $shipping_cost_express ) ? round( floatval( $shipping_cost_express ), wc_get_price_decimals() ) : '',
					'cdata' => false,
				);
				//Minimum preparation time
				$preparation_days_min = apply_filters( 'kuantokusta_product_node_default_preparation_days_min', $this->get_product_preparation_days_min( $product ), $product, $product_type );
				$xml_fields['preparation_days_min'] = array(
					'value' => ! empty( $preparation_days_min ) ? intval( $preparation_days_min ) : '',
					'cdata' => false,
				);
				//Minimum delivery time
				$delivery_days_min = apply_filters( 'kuantokusta_product_node_default_delivery_days_min', $this->get_product_delivery_days_min( $product ), $product, $product_type );
				$xml_fields['delivery_days_min'] = array(
					'value' => ! empty( $delivery_days_min ) ? intval( $delivery_days_min ) : '',
					'cdata' => false,
				);
				//Minimum express delivery time
				$delivery_days_min_express = apply_filters( 'kuantokusta_product_node_default_delivery_days_min_express', $this->get_product_express_delivery_days_min( $product ), $product, $product_type );
				$xml_fields['delivery_days_min_express'] = array(
					'value' => ! empty( $delivery_days_min_express ) ? intval( $delivery_days_min_express ) : '',
					'cdata' => false,
				);
				//Maximum express delivery time
				$delivery_days_max_express = apply_filters( 'kuantokusta_product_node_default_delivery_days_max_express', $this->get_product_express_delivery_days_max( $product ), $product, $product_type );
				$xml_fields['delivery_days_max_express'] = array(
					'value' => ! empty( $delivery_days_max_express ) ? intval( $delivery_days_max_express ) : '',
					'cdata' => false,
				);
				//Additional images
				$images = $this->get_product_additional_images( $product );
				foreach ( $images as $i => $image ) {
					$xml_fields['image_url_'.$i] = array(
						'value' => apply_filters( 'kuantokusta_product_node_default_image_'.$i, $image, $product, $product_type ),
						'cdata' => true,
					);
				}
				//Custom attributes - WooCommerce product attributes
				$atts = $this->get_product_attributes( $product );
				foreach ( $atts as $key => $value ) {
					$xml_fields['product_attribute_'.$key] = array(
						'value' => apply_filters( 'kuantokusta_product_node_default_product_attribute_'.$key, $value, $product, $product_type ),
						'cdata' => true,
					);
				}
				//Custom attributes - Custom fields
				//v2
			}
		}
		return $xml_fields;
	}
	public function product_node_variation_xml_fields( $xml_fields, $product, $variation ) {
		if ( $this->license_validated() ) {
			if ( WC_Feed_KuantoKusta()->mode == 'marketplace' ) {
				//Brand SKU / MPN
				//Get from variation, if it exists
				if ( trim( $variation->get_meta( '_kuantokusta_brand_sku' ) ) != '' ) {
					$brand_sku = trim( $variation->get_meta( '_kuantokusta_brand_sku' ) );
				} else {
					$brand_sku = $product->get_meta( '_kuantokusta_brand_sku' );
				}
				$brand_sku = apply_filters( 'kuantokusta_product_node_variation_brand_ref', $this->get_field_from_origin( $brand_sku, 'brand_ref_origin', $product, $variation ), $product, $variation );
				$xml_fields['brand_ref'] = array(
					'value' => trim( $brand_sku ),
					'cdata' => true,
				);
				//Shipping cost (express)
				$shipping_cost_express = apply_filters( 'kuantokusta_product_node_variation_shipping_express', $this->get_product_shipping_cost_express( $product ), $product, $variation );
				$xml_fields['shipping_cost_express'] = array(
					'value' => round( floatval( $shipping_cost_express ), wc_get_price_decimals() ),
					'cdata' => false,
				);
				//Minimum preparation time
				$preparation_days_min = apply_filters( 'kuantokusta_product_node_variation_preparation_days_min', $this->get_product_variation_preparation_days_min( $product, $variation ), $product, $variation );
				$xml_fields['preparation_days_min'] = array(
					'value' => ! empty( $preparation_days_min ) ? intval( $preparation_days_min ) : '',
					'cdata' => false,
				);
				//Minimum delivery time
				$delivery_days_min = apply_filters( 'kuantokusta_product_node_variation_delivery_days_min', $this->get_product_delivery_days_min( $product ), $product, $variation );
				$xml_fields['delivery_days_min'] = array(
					'value' => ! empty( $delivery_days_min ) ? intval( $delivery_days_min ) : '',
					'cdata' => false,
				);
				//Minimum express delivery time
				$delivery_days_min_express = apply_filters( 'kuantokusta_product_node_variation_delivery_days_min_express', $this->get_product_express_delivery_days_min( $product ), $product, $variation );
				$xml_fields['delivery_days_min_express'] = array(
					'value' => ! empty( $delivery_days_min_express ) ? intval( $delivery_days_min_express ) : '',
					'cdata' => false,
				);
				//Maximum express delivery time
				$delivery_days_max_express = apply_filters( 'kuantokusta_product_node_variation_delivery_days_max_express', $this->get_product_express_delivery_days_max( $product ), $product, $variation );
				$xml_fields['delivery_days_max_express'] = array(
					'value' => ! empty( $delivery_days_max_express ) ? intval( $delivery_days_max_express ) : '',
					'cdata' => false,
				);
				//Additional images - same as parent product
				$images = $this->get_product_additional_images( $product );
				foreach ( $images as $i => $image ) {
					$xml_fields['image_url_'.$i] = array(
						'value' => apply_filters( 'kuantokusta_product_node_variation_image_'.$i, $image, $product, $variation ),
						'cdata' => true,
					);
				}
				//Custom attributes - WooCommerce product attributes
				$atts = $this->get_product_attributes( $variation );
				foreach ( $atts as $key => $value ) {
					$xml_fields['product_attribute_'.$key] = array(
						'value' => apply_filters( 'kuantokusta_product_node_variation_product_attribute_'.$key, $value, $product, $variation ),
						'cdata' => true,
					);
				}
				//Custom attributes - Custom fields
				//v2
			}
		}
		return $xml_fields;
	}

	/* Add fields to documentation */
	public function kuantokusta_documentation_fields( $fields ) {
		foreach ( $this->fields as $key => $field ) {
			if ( isset( $field['documentation'] ) && $field['documentation'] ) {
				if ( $field[WC_Feed_KuantoKusta()->mode] ) {
					$fields[$field['documentation']['id']] = array(
						'desc'        => $field['documentation']['desc'],
						'filter'      => $field['documentation']['filter'],
						'comparison'  => $field['comparison'],
						'marketplace' => $field['marketplace'],
					);
				}
			}
		}
		return $fields;
	}

	/* Add hooks to documentation */
	public function kuantokusta_documentation_hooks( $fields ) {
		foreach ( $this->fields as $key => $field ) {
			if ( isset( $field['hooks']['filters'] ) && $field['hooks']['filters'] ) {
				foreach( $field['hooks']['filters'] as $filter => $filterinfo ) {
					if ( $field[WC_Feed_KuantoKusta()->mode] ) {
						$fields['filters'][$filter] = $filterinfo;
					}
				}
			}
		}
		return $fields;
	}

}

/* If you're reading this you must know what you're doing ;-) Greetings from sunny Portugal! */
