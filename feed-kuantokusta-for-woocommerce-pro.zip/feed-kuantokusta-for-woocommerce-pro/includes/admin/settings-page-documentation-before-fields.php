<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
	<?php if( $this->wpml_active ) { ?>

		<h3><?php _e( 'WPML / WooCommerce Multilingual feed URL', 'feed-kuantokusta-for-woocommerce-pro' ); ?></h3>

		<ul>
			<?php
			$langs = icl_get_languages( 'skip_missing=0' );
			global $sitepress;
			foreach ( $langs as $key => $lang ) {
				$sitepress->switch_lang( $key );
				$url = get_feed_link( 'kuantokusta' );
				?>
				<li>
					- <?php echo $lang['native_name']; ?>: <?php echo '<a href="'.esc_url( $url ).'?TOTAL_PRODUTOS=100&LIMIT=0" target="_blank">'.$url.'</a>'; ?>
				</li>
				<?php
			}
			$sitepress->switch_lang( ICL_LANGUAGE_CODE );
			?>
		</ul>

	<?php } ?>

	<style type="text/css">
		.kk_settings_section_hide_free {
			display: block !important;
		}
		.kk_settings_section_hide_pro {
			display: none;
		}
	</style>