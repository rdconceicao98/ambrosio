<?php
/**
 * Plugin Name: Feed KuantoKusta for WooCommerce - PRO add-on
 * Plugin URI: https://www.webdados.pt/wordpress/plugins/feed-kuantokusta-para-woocommerce/
 * Description: This plugin extends the functionality of the free plugin available on the WordPress.org plugin repository
 * Version: 3.2
 * Author: PT Woo Plugins (by Webdados)
 * Author URI: https://ptwooplugins.com
 * Text Domain: feed-kuantokusta-for-woocommerce-pro
 * Domain Path: /languages
 * Requires at least: 5.4
 * Tested up to: 6.7
 * Requires PHP: 7.0
 * WC requires at least: 7.0
 * WC tested up to: 9.4
 * Update URI: false
 * Requires Plugins: woocommerce, feed-kuantokusta-for-woocommerce
**/

/* WooCommerce CRUD ready */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define( 'KUANTOKUSTA_PRO_REQUIRED_FREE', '3.1' );
define( 'KUANTOKUSTA_PRO_REQUIRED_WC', '7.0' );

/* Localization */
add_action( 'init', 'fkkwcpro_load_textdomain', 0 );
function fkkwcpro_load_textdomain() {
	load_plugin_textdomain( 'feed-kuantokusta-for-woocommerce-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}

/* Our own order class and the main classes */
add_action( 'init', 'fkkwcpro_init', 2 );
function fkkwcpro_init() {
	if ( class_exists( 'WooCommerce' ) && version_compare( WC_VERSION, KUANTOKUSTA_PRO_REQUIRED_WC, '>=' ) && function_exists( 'WC_Feed_KuantoKusta' ) && version_compare( WC_Feed_KuantoKusta()->version, KUANTOKUSTA_PRO_REQUIRED_FREE, '>=' ) ) { //We check again because WooCommerce could have "died"
		define( 'KUANTOKUSTA_PRO_PLUGIN_FILE', __FILE__ );
		define( 'KUANTOKUSTA_PRO_PLUGIN_SLUG', basename( __FILE__ ) );
		define( 'KUANTOKUSTA_PRO_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
		define( 'KUANTOKUSTA_PRO_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
		require_once( dirname( __FILE__ ) . '/includes/class-wc-feed-kuantokusta-pro.php' );
		$GLOBALS['WC_Feed_KuantoKusta_Pro'] = WC_Feed_KuantoKusta_Pro();
		/* Add settings links - This is here because inside the main class we cannot call the correct plugin_basename( __FILE__ ) */
		add_filter( 'plugin_action_links_'.plugin_basename( __FILE__ ), array( WC_Feed_KuantoKusta_Pro(), 'add_settings_link' ) );
		add_filter( 'kk_webdados_invoicexpress_nag', '__return_false' );
	} else {
		add_action( 'admin_notices', 'admin_notices_kuantokusta_woocommerce_pro_not_active' );
	}
}

/* Main class */
function WC_Feed_KuantoKusta_Pro() {
	return WC_Feed_KuantoKusta_Pro::instance();
}

/* Dependencies notice */
function admin_notices_kuantokusta_woocommerce_pro_not_active() {
	?>
	<div class="notice notice-error is-dismissible">
		<p>
			<?php
				echo wp_kses_post(
					sprintf(
						__( '<strong>Feed KuantoKusta for WooCommerce PRO add-on</strong> is installed and active but <strong>Feed KuantoKusta for WooCommerce (%1$s or above)</strong> and <strong>WooCommerce (%2$s or above)</strong> are not.', 'feed-kuantokusta-for-woocommerce-pro' ),
						KUANTOKUSTA_PRO_REQUIRED_FREE,
						KUANTOKUSTA_PRO_REQUIRED_WC
					)
				);
				;
			?>
		</p>
	</div>
	<?php
}

/* HPOS Compatible */
add_action( 'before_woocommerce_init', function() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
} );

/* If you're reading this you must know what you're doing ;-) Greetings from sunny Portugal! */
