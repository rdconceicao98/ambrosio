(function(e,t,n,r,i,s,o){e["KuantoKusta_trackk"]=i;e[i]=e[i]||function(){e[i].q
=e[i].q||[];e[i].q.push(arguments)};e[i].l=1*new Date;s=t.createElement(n),o=
t.getElementsByTagName(n)[0];s.async=1;s.src=r;o.parentNode.insertBefore(s,o)})
(window,document,"script","https://s1.kuantokusta.pt/js/trackk-1.2.min.js","__trackk");
__trackk('create', wc_feed_kuantokusta.storeId, wc_feed_kuantokusta.serverAddr);
__trackk('send', 'pageview');